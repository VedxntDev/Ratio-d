/**
 * Ratio'd Shadow DOM Banner Injector for Gmail
 * Features:
 * - Isolated Shadow DOM Neo-Brutalist Banner
 * - One-Click Unsubscribe Engine
 * - Web Audio API Synthesized Sparkle Chime Sound Effect
 * - Glitter & Confetti Canvas Burst Particle System
 */

/** True when the OS requests reduced motion. */
function prefersReducedMotion() {
  try {
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch (e) {
    return false;
  }
}

/**
 * Escape text before it goes anywhere near innerHTML.
 *
 * The banner runs inside a content script on mail.google.com and interpolates
 * attacker-controlled data: `flags[].span` is a substring of the email body,
 * and `explanation` can be LLM-generated. Without escaping, an email
 * containing markup would execute in the user's Gmail session.
 */
function escapeHtml(value) {
  return String(value === undefined || value === null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function extractCleanEmail(raw) {
  if (!raw || typeof raw !== "string") return "";
  const s = raw.trim();
  const angleMatch = s.match(/<([^>@]+@[^>@]+)>/);
  if (angleMatch) return angleMatch[1].trim().toLowerCase();
  const emailMatch = s.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
  if (emailMatch) return emailMatch[1].trim().toLowerCase();
  return "";
}

function extractEmailDomain(email) {
  const clean = extractCleanEmail(email);
  if (!clean || !clean.includes("@")) return "";
  return clean.split("@")[1].toLowerCase().trim();
}

function playUnsubscribeSparkleSound() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    // Chime Note 1: E5 (659.25Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = "sine";
    osc1.frequency.setValueAtTime(659.25, now);
    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.3);

    // Chime Note 2: A5 (880Hz)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = "sine";
    osc2.frequency.setValueAtTime(880, now + 0.08);
    gain2.gain.setValueAtTime(0.2, now + 0.08);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.08);
    osc2.stop(now + 0.4);

    // Chime Note 3: C#6 Sparkling Chime (1108.73Hz)
    const osc3 = ctx.createOscillator();
    const gain3 = ctx.createGain();
    osc3.type = "triangle";
    osc3.frequency.setValueAtTime(1108.73, now + 0.16);
    gain3.gain.setValueAtTime(0.25, now + 0.16);
    gain3.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc3.connect(gain3);
    gain3.connect(ctx.destination);
    osc3.start(now + 0.16);
    osc3.stop(now + 0.55);
  } catch (e) {
    console.log("[AUDIO SYNTH] AudioContext playback:", e);
  }
}

function launchGlitterBurst(shadowRoot, originButton) {
  const container = shadowRoot.querySelector(".ratiod-container");
  if (!container) return;

  const canvas = document.createElement("canvas");
  canvas.style.position = "absolute";
  canvas.style.top = "0";
  canvas.style.left = "0";
  canvas.style.width = "100%";
  canvas.style.height = "100%";
  canvas.style.pointerEvents = "none";
  canvas.style.zIndex = "999";
  
  const rect = container.getBoundingClientRect();
  canvas.width = rect.width;
  canvas.height = rect.height;
  container.appendChild(canvas);

  const ctx = canvas.getContext("2d");
  const particles = [];
  const colors = ["#F5C242", "#EA3E2B", "#E8720C", "#FFFFFF", "#8A8B5C", "#121212"];

  const btnRect = originButton.getBoundingClientRect();
  const startX = (btnRect.left + btnRect.width / 2) - rect.left;
  const startY = (btnRect.top + btnRect.height / 2) - rect.top;

  // Create 45 glitter particles
  for (let i = 0; i < 45; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 3 + Math.random() * 7;
    particles.push({
      x: startX,
      y: startY,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed - 1.5,
      size: 4 + Math.random() * 6,
      color: colors[Math.floor(Math.random() * colors.length)],
      alpha: 1,
      rotation: Math.random() * Math.PI,
      vRot: (Math.random() - 0.5) * 0.2
    });
  }

  let startTime = null;

  function animate(timestamp) {
    if (!startTime) startTime = timestamp;
    const elapsed = timestamp - startTime;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let activeParticles = 0;
    particles.forEach(p => {
      if (p.alpha > 0) {
        activeParticles++;
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.15; // Gravity
        p.alpha -= 0.018; // Fade
        p.rotation += p.vRot;

        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.fillStyle = p.color;

        // Draw star/glitter square particle
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }
    });

    if (activeParticles > 0 && elapsed < 1500) {
      requestAnimationFrame(animate);
    } else {
      canvas.remove();
    }
  }

  requestAnimationFrame(animate);
}

function injectRatiodBanner(targetElement, data) {
  if (!targetElement || !document.body.contains(targetElement)) {
    const candidate = document.querySelector(
      ".adn.ads:not([style*='display: none']) .ii.gt, .adn.ads:not([style*='display: none']) .a3s, .ii.gt, .a3s.aiL, .a3s"
    );
    if (candidate && document.body.contains(candidate)) {
      targetElement = candidate;
    } else {
      return;
    }
  }

  const existingHost = document.getElementById("ratiod-banner-host");
  if (existingHost) {
    existingHost.remove();
  }

  const host = document.createElement("div");
  host.id = "ratiod-banner-host";
  const isDarkTheme = (data && data.theme === "dark") ||
                      (typeof document !== "undefined" && document.documentElement && document.documentElement.getAttribute("data-ratiod-theme") === "dark");
  if (isDarkTheme) {
    host.setAttribute("data-theme", "dark");
  }
  const shadowRoot = host.attachShadow({ mode: "open" });

  const styleElem = document.createElement("style");
  styleElem.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@500;700&display=swap');

    :host {
      all: initial;
      display: block;
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Inter', 'SF Pro Display', 'Segoe UI', Roboto, sans-serif;
      margin: 6px 0 10px 0;
      width: 100%;
    }

    * {
      box-sizing: border-box;
    }

    .ratiod-container {
      background-color: #FFFFFF;
      border: 1px solid rgba(0, 0, 0, 0.08);
      border-radius: 12px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02);
      color: #1F2937;
      padding: 10px 14px;
      position: relative;
      overflow: hidden;
      transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }

    /* Ambient Micro-Pill for Safe Emails (Zero Layout Displacement) */
    .ratiod-container.ambient-safe-mode {
      padding: 6px 14px;
      border-radius: 9999px;
      background-color: #FFFFFF;
      border: 1px solid #D1FAE5;
      border-left: 3.5px solid #10B981;
      box-shadow: 0 1px 3px rgba(16, 185, 129, 0.06);
      margin: 4px 0 8px 0;
      transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .ratiod-container.ambient-safe-mode.expanded {
      border-radius: 12px;
      padding: 12px 16px;
    }

    /* Compact Sleek Mode for Promotional Newsletters */
    .ratiod-container.compact-promo-mode {
      padding: 6px 14px;
      border-radius: 12px;
      background-color: #FFFFFF;
      border: 1px solid #E0E7FF;
      border-left: 3.5px solid #6366F1;
      box-shadow: 0 1px 3px rgba(99, 102, 241, 0.06);
      margin: 4px 0 8px 0;
    }

    /* Themed edge accents */
    .ratiod-container.theme-promo_clutter {
      border-left: 3.5px solid #6366F1;
      border-color: #E0E7FF;
    }

    .ratiod-container.theme-safe {
      border-left: 3.5px solid #10B981;
      border-color: #D1FAE5;
    }

    .ratiod-container.theme-suspicious {
      border-left: 3.5px solid #F59E0B;
      background-color: #FFFDF7;
      border-color: #FED7AA;
    }

    .ratiod-container.theme-high_risk {
      border-left: 3.5px solid #EF4444;
      background-color: #FEF8F8;
      border-color: #FECACA;
    }

    .ratiod-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
    }

    .ratiod-badge-group {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 8px;
    }

    .ratiod-tag {
      font-family: inherit;
      font-size: 11.5px;
      font-weight: 700;
      padding: 3px 10px;
      border-radius: 9999px;
      border: 1px solid transparent;
      letter-spacing: 0.1px;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      white-space: nowrap;
    }

    .tag-high_risk { background-color: #FEF2F2; color: #991B1B; border-color: #FECACA; }
    .tag-promo_clutter { background-color: #EEF2FF; color: #4338CA; border-color: #C7D2FE; }
    .tag-suspicious { background-color: #FFFBEB; color: #92400E; border-color: #FDE68A; }
    .tag-safe { background-color: #ECFDF5; color: #065F46; border-color: #A7F3D0; }
    .tag-auth-spoof { background-color: #FEF2F2; color: #991B1B; border-color: #FECACA; font-size: 11px; padding: 2px 7px; }
    .tag-auth-verified { background-color: #ECFDF5; color: #065F46; border-color: #A7F3D0; font-size: 11px; padding: 2px 7px; }
    .tag-auth-unverified { background-color: #F3F4F6; color: #4B5563; border-color: #E5E7EB; font-size: 11px; padding: 2px 7px; }

    /* Brand mark */
    .ratiod-logo {
      border-radius: 6px;
      flex: 0 0 auto;
      display: block;
    }

    /* Visually hidden text for screen readers on icon-only buttons. */
    .sr-only {
      position: absolute;
      width: 1px; height: 1px;
      padding: 0; margin: -1px;
      overflow: hidden;
      clip: rect(0 0 0 0);
      white-space: nowrap;
      border: 0;
    }

    .ratiod-header-actions { display: flex; align-items: center; gap: 6px; }

    .ratiod-iconbtn {
      display: inline-grid;
      place-items: center;
      width: 24px; height: 24px;
      padding: 0;
      border-radius: 9999px;
      border: 1px solid rgba(0, 0, 0, 0.1);
      background-color: #FFFFFF;
      color: #374151;
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      transition: background-color 0.15s ease;
    }
    .ratiod-iconbtn:hover { background-color: #F3F4F6; }
    .ratiod-iconbtn:focus-visible,
    .ratiod-btn:focus-visible,
    .ratiod-cred:focus-visible {
      outline: 2px solid #EA3E2B;
      outline-offset: 2px;
    }

    /* Collapsed state: keep the score visible, hide the advice + actions. */
    .ratiod-body.collapsed { display: none; }

    /* Author credit, mirroring the site footer. */
    .ratiod-credit {
      margin-top: 10px;
      padding-top: 8px;
      border-top: 1px solid rgba(0, 0, 0, 0.08);
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 10.5px;
      color: #6B7280;
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }
    .ratiod-cred { color: #1F2937; font-weight: 600; text-decoration: underline; }
    .ratiod-cred:hover { color: #EA3E2B; }

    /* Respect the OS "reduce motion" setting: no confetti, no sound surprises. */
    @media (prefers-reduced-motion: reduce) {
      .ratiod-container, .ratiod-btn { transition: none; }
    }

    .ratiod-score {
      font-family: 'Google Sans', Roboto, -apple-system, sans-serif;
      font-size: 11.5px;
      font-weight: 600;
      background-color: #FFFFFF;
      border: 1px solid rgba(0, 0, 0, 0.1);
      padding: 3px 8px;
      border-radius: 9999px;
      display: inline-flex;
      align-items: center;
      box-shadow: 0 1px 2px rgba(0,0,0,0.03);
      gap: 5px;
      white-space: nowrap;
    }

    .ratiod-score-mail {
      background-color: #FFFFFF;
      color: #1F2937;
    }

    .score-type-badge {
      display: inline-block;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.3px;
      padding: 1px 5px;
      border-radius: 4px;
      background: #F3F4F6;
      color: #374151;
      text-transform: uppercase;
      vertical-align: middle;
    }

    .score-number {
      font-size: 13px;
      font-weight: 800;
      color: #111827;
    }

    .score-denom {
      font-size: 10.5px;
      font-weight: 600;
      color: #6B7280;
    }

    .score-level-badge {
      font-size: 9px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 9999px;
      text-transform: uppercase;
    }
    .level-low { background-color: #DCFCE7; color: #166534; }
    .level-promo { background-color: #FEF08A; color: #854D0E; }
    .level-med { background-color: #FFEDD5; color: #9A3412; }
    .level-high { background-color: #FEE2E2; color: #991B1B; }

    .ratiod-score-qr {
      background-color: #FFFFFF;
      color: #1F2937;
      transition: background-color 0.2s ease, color 0.2s ease;
    }

    .ratiod-score-qr.qr-high_risk, .ratiod-score-qr.qr-malicious {
      background-color: #FEE2E2;
      color: #991B1B;
      border-color: #FCA5A5;
    }

    .ratiod-score-qr.qr-suspicious {
      background-color: #FFEDD5;
      color: #9A3412;
      border-color: #FDBA74;
    }

    .ratiod-score-qr.qr-safe {
      background-color: #DCFCE7;
      color: #166534;
      border-color: #86EFAC;
    }

    .ratiod-score-qr.qr-none {
      background-color: #FFFFFF;
      color: #6B7280;
    }

    .ratiod-score-qr.qr-high_risk .score-type-badge,
    .ratiod-score-qr.qr-malicious .score-type-badge {
      background: #FFFFFF;
      color: #DC2626;
      border-color: #FCA5A5;
    }

    .drawer-sub-heading {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 700;
      color: #4A4741;
      margin: 4px 0 8px 0;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .qr-banner-card {
      background: #FFFFFF;
      border: 1.5px solid #121212;
      border-radius: 8px;
      padding: 10px 12px;
      margin: 6px 0 10px 0;
      box-shadow: 2px 2px 0 #121212;
    }

    .qr-banner-card.card-high_risk, .qr-banner-card.card-malicious {
      border-left: 6px solid #EA3E2B;
    }
    .qr-banner-card.card-suspicious {
      border-left: 6px solid #E8720C;
    }
    .qr-banner-card.card-safe {
      border-left: 6px solid #9BE86D;
    }

    .qr-banner-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 6px;
    }

    .qr-banner-payload-label {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 800;
      color: #121212;
      text-transform: uppercase;
      margin-top: 6px;
    }

    .qr-banner-code {
      display: block;
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      word-break: break-all;
      background: #F8F7F2;
      border: 1.5px dashed #121212;
      padding: 6px 10px;
      border-radius: 6px;
      margin: 6px 0;
      color: #121212;
    }

    .ratiod-body { margin-top: 12px; }

    .ratiod-summary-card {
      background-color: #FFFFFF;
      border: 1px solid rgba(0, 0, 0, 0.08);
      border-radius: 10px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
      padding: 12px 14px;
      margin-top: 8px;
    }

    .ratiod-summary-header {
      display: flex;
      align-items: flex-start;
      gap: 10px;
    }

    .ratiod-summary-icon {
      font-size: 20px;
      line-height: 1;
      flex-shrink: 0;
      margin-top: 1px;
    }

    .ratiod-summary-content {
      flex: 1;
    }

    .ratiod-summary-title {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 3px;
    }

    .ratiod-summary-lead {
      font-size: 13px;
      line-height: 1.5;
      color: #4B5563;
      font-weight: 400;
    }

    .ratiod-summary-tip {
      margin-top: 6px;
      padding: 6px 10px;
      background-color: #F9FAFB;
      border-left: 3px solid #16A34A;
      border-radius: 4px;
      font-size: 12px;
      line-height: 1.4;
      color: #374151;
    }

    .ratiod-explanation {
      margin-top: 8px;
      padding-top: 6px;
      border-top: 1px dashed #E5E7EB;
      font-size: 12px;
      line-height: 1.5;
      color: #4B5563;
      font-weight: 400;
    }

    .ratiod-explanation-label {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 10.5px;
      font-weight: 700;
      text-transform: uppercase;
      background-color: #F3F4F6;
      color: #374151;
      padding: 1px 6px;
      border-radius: 9999px;
      margin-right: 5px;
    }

    .ratiod-actions {
      display: flex;
      gap: 8px;
      margin-top: 12px;
      flex-wrap: wrap;
    }

    .ratiod-btn {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      padding: 6px 14px;
      border-radius: 9999px;
      border: 1px solid rgba(0, 0, 0, 0.1);
      background-color: #FFFFFF;
      color: #374151;
      cursor: pointer;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
      transition: background-color 0.15s ease, box-shadow 0.15s ease;
      display: inline-flex;
      align-items: center;
      gap: 5px;
    }

    .ratiod-btn:hover {
      background-color: #F3F4F6;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.06);
    }

    .ratiod-btn-primary { background-color: #F3F4F6; color: #1F2937; border-color: #E5E7EB; }
    .ratiod-btn-primary:hover { background-color: #E5E7EB; color: #111827; }
    .ratiod-btn-unsub,
    .btn-highlight-unsub {
      background: linear-gradient(135deg, #4F46E5 0%, #6366F1 100%) !important;
      color: #FFFFFF !important;
      border: none !important;
      font-weight: 600 !important;
      box-shadow: 0 1px 3px rgba(79, 70, 229, 0.3) !important;
    }
    .ratiod-btn-unsub:hover,
    .btn-highlight-unsub:hover {
      background: linear-gradient(135deg, #4338CA 0%, #4F46E5 100%) !important;
      box-shadow: 0 2px 6px rgba(79, 70, 229, 0.4) !important;
    }
    .ratiod-btn-spam { background-color: #FFFFFF; color: #DC2626; border-color: #FCA5A5; }
    .ratiod-btn-spam:hover { background-color: #FEF2F2; }
    .btn-highlight-spam {
      background-color: #DC2626 !important;
      color: #FFFFFF !important;
      border-color: #DC2626 !important;
      font-weight: 600 !important;
    }

    .ratiod-feedback-strip {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 8px;
      padding-top: 6px;
      border-top: 1px dashed #E5E7EB;
    }

    .ratiod-feedback-prompt {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 11px;
      font-weight: 600;
      color: #6B7280;
    }

    .ratiod-feedback-chips {
      display: flex;
      gap: 6px;
      align-items: center;
    }

    .ratiod-chip-btn {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 11px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 9999px;
      border: 1px solid rgba(0, 0, 0, 0.1);
      background: #FFFFFF;
      color: #374151;
      cursor: pointer;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
      transition: background 0.15s ease;
    }

    .ratiod-chip-btn:hover {
      background: #F3F4F6;
    }

    .ratiod-chip-btn.chip-active {
      background: #111827;
      color: #FFFFFF;
      border-color: #111827;
    }

    .ratiod-feedback-toast {
      margin-top: 6px;
      padding: 6px 10px;
      background: #ECFDF5;
      border: 1px solid #10B981;
      border-radius: 6px;
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 11.5px;
      font-weight: 600;
      color: #065F46;
    }

    .btn-highlight-safe {
      background-color: #DCFCE7 !important;
      color: #166534 !important;
      border-color: #86EFAC !important;
      font-weight: 600 !important;
    }

    .btn-highlight-unsafe {
      background-color: #FEE2E2 !important;
      color: #991B1B !important;
      border-color: #FCA5A5 !important;
      font-weight: 600 !important;
    }

    .tag-user-safe {
      background-color: #DCFCE7 !important;
      color: #166534 !important;
      border-color: #86EFAC !important;
    }

    .tag-user-unsafe {
      background-color: #FEE2E2 !important;
      color: #991B1B !important;
      border-color: #FCA5A5 !important;
    }

    .tag-user-promo {
      background-color: #FEF08A !important;
      color: #854D0E !important;
      border-color: #FACC15 !important;
    }

    .tag-user-suspicious {
      background-color: #FFEDD5 !important;
      color: #9A3412 !important;
      border-color: #FDBA74 !important;
    }

    .ratiod-header-action-btn {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 11.5px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 9999px;
      border: 1px solid rgba(0, 0, 0, 0.1);
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
      cursor: pointer;
      transition: background-color 0.15s ease;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      margin-left: 4px;
    }

    .ratiod-header-action-btn.btn-highlight-safe {
      background-color: #DCFCE7;
      color: #166534;
      border-color: #86EFAC;
    }
    .ratiod-header-action-btn.btn-highlight-safe:hover {
      background-color: #BBF7D0;
    }
    .ratiod-header-action-btn.btn-highlight-unsafe {
      background-color: #FEE2E2;
      color: #991B1B;
      border-color: #FCA5A5;
    }
    .ratiod-header-action-btn.btn-highlight-unsafe:hover {
      background-color: #FECACA;
    }

    .ratiod-feedback-label-box {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .ratiod-feedback-sub {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 11px;
      color: #6B7280;
      font-weight: 500;
    }

    .ratiod-drawer {
      display: none;
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px dashed rgba(0, 0, 0, 0.12);
    }

    .ratiod-drawer.open { display: block; }

    .drawer-section-title {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 6px;
      color: #374151;
    }

    .flag-item {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11.5px;
      background: #FFFFFF;
      border: 1px solid rgba(0, 0, 0, 0.08);
      padding: 6px 10px;
      border-radius: 6px;
      margin-bottom: 6px;
      box-shadow: 0 1px 2px rgba(0,0,0,0.02);
    }

    .flag-span { font-weight: 700; color: #DC2626; text-decoration: underline; }
    .flag-peek-btn {
      font-family: 'Google Sans', Roboto, sans-serif;
      font-size: 10.5px;
      font-weight: 600;
      padding: 2px 8px;
      margin-left: 8px;
      border: 1px solid rgba(0, 0, 0, 0.12);
      background: #FFFFFF;
      color: #374151;
      border-radius: 9999px;
      cursor: pointer;
      box-shadow: 0 1px 2px rgba(0,0,0,0.04);
    }
    .flag-peek-btn:hover { background: #F3F4F6; }
    .flag-peek-res {
      margin-top: 6px;
      padding: 6px 8px;
      background: #F9FAFB;
      border: 1px dashed #D1D5DB;
      border-radius: 4px;
      font-size: 11px;
      line-height: 1.4;
    }

    .checklist-list { padding-left: 18px; margin: 6px 0; font-size: 13px; }
    .checklist-list li { margin-bottom: 4px; }

    .privacy-footnote {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: #8A8B5C;
      margin-top: 10px;
    }

    /* ==========================================================================
       Dark Mode Adaptive Styling
       Applies when Gmail theme is dark OR OS prefers dark
       ========================================================================== */
    :host([data-theme="dark"]) .ratiod-container,
    @media (prefers-color-scheme: dark) {
      .ratiod-container {
        background-color: #18181B;
        border-color: rgba(255, 255, 255, 0.08);
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
        color: #F4F4F5;
      }
      .ratiod-container.ambient-safe-mode {
        background-color: #18181B;
        border-color: rgba(255, 255, 255, 0.08);
        border-left: 3.5px solid #10B981;
        color: #F4F4F5;
      }
      .ratiod-container.compact-promo-mode {
        background-color: #18181B;
        border-color: rgba(255, 255, 255, 0.08);
        border-left: 3.5px solid #6366F1;
        color: #F4F4F5;
      }
      .ratiod-container.theme-safe {
        background-color: #18181B;
        border-left: 3.5px solid #10B981;
      }
      .ratiod-container.theme-promo_clutter {
        background-color: #18181B;
        border-left: 3.5px solid #6366F1;
      }
      .ratiod-container.theme-suspicious {
        background-color: #18181B;
        border-left: 3.5px solid #F59E0B;
        border-color: rgba(245, 158, 11, 0.25);
      }
      .ratiod-container.theme-high_risk {
        background-color: #18181B;
        border-left: 3.5px solid #EF4444;
        border-color: rgba(239, 68, 68, 0.25);
      }
      .ratiod-summary-card {
        background-color: #202024;
        border-color: #3F3F46;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
        color: #F4F4F5;
      }
      .ratiod-summary-title {
        color: #F4F4F5;
      }
      .ratiod-summary-lead {
        color: #E4E4E7;
      }
      .ratiod-summary-tip {
        background-color: #27272A;
        border-left-color: #10B981;
        color: #D4D4D8;
      }
      .ratiod-explanation {
        border-top-color: #3F3F46;
        color: #A1A1AA;
      }
      .ratiod-explanation-label {
        background-color: #3F3F46;
        color: #F4F4F5;
      }
      .ratiod-btn {
        background-color: #27272A;
        color: #F4F4F5;
        border-color: #3F3F46;
      }
      .ratiod-btn:hover {
        background-color: #3F3F46;
      }
      .flag-item {
        background-color: #27272A;
        border-color: #3F3F46;
        color: #F4F4F5;
      }
      .flag-peek-res {
        background-color: #18181B;
        border-color: #52525B;
        color: #E4E4E7;
      }
      .ratiod-feedback-strip {
        background-color: #202024;
        border-color: #3F3F46;
      }
      .ratiod-feedback-prompt {
        color: #F4F4F5;
      }
      .ratiod-feedback-sub {
        color: #A1A1AA;
      }
      .ratiod-chip-btn {
        background-color: #27272A;
        color: #F4F4F5;
        border-color: #3F3F46;
      }
      .ratiod-chip-btn:hover {
        background-color: #3F3F46;
      }
      .drawer-toggle {
        background-color: #27272A;
        color: #F4F4F5;
        border-color: #3F3F46;
      }
      .vega-pill, .diag-row {
        background-color: #202024;
        border-color: #3F3F46;
        color: #E4E4E7;
      }
      .privacy-footnote {
        color: #A1A1AA;
      }
      .ratiod-iconbtn {
        background-color: #27272A;
        color: #F4F4F5;
        border-color: #3F3F46;
      }
      .ratiod-iconbtn:hover {
        background-color: #3F3F46;
      }
      .ratiod-score-mail {
        background-color: #27272A;
        color: #F4F4F5;
        border-color: #3F3F46;
      }
      .score-type-badge {
        background-color: #3F3F46;
        color: #F4F4F5;
      }
      .score-number {
        color: #FFFFFF;
      }
    }
  `;
  shadowRoot.appendChild(styleElem);

  const verdict = data.verdict || "safe";
  const mailScore = data.mail_score !== undefined ? data.mail_score : (data.score !== undefined ? data.score : 0);
  const score = data.score !== undefined ? data.score : mailScore;
  const flags = data.flags || [];
  const explanation = data.explanation || "No threat signals detected.";
  const nextSteps = data.next_steps || [];
  const privacy = data.privacy || { phones_masked: 0, emails_masked: 0, otp_masked: 0 };
  const totalMasked = (privacy.phones_masked || 0) + (privacy.emails_masked || 0) + (privacy.otp_masked || 0);

  const engine = data.engine || {};
  const vegaSource = engine.model_source || "edge_physics";
  const vegaThreatBasin = (engine.model_threat_category || verdict || "safe").toUpperCase();
  const vegaConvergence = engine.model_abstain ? "ABSTAIN (Unbound OOD Orbit)" : "CONVERGED (Harmonic Well)";
  const vegaConformalSet = Array.isArray(engine.model_conformal_set) && engine.model_conformal_set.length > 0
    ? engine.model_conformal_set.join(", ")
    : (verdict || "safe");
  const vegaTemp = engine.model_temperature !== undefined ? Number(engine.model_temperature).toFixed(3) : "1.000";
  const vegaKinetic = engine.model_kinetic_energy !== undefined ? Number(engine.model_kinetic_energy).toFixed(4) : "0.0000";

  const isSafe = verdict === "safe";
  const isPromo = verdict === "promo_clutter";

  const container = document.createElement("div");
  container.className = "ratiod-container theme-" + (isPromo ? "promo_clutter" : (verdict || "safe")) +
    (isSafe ? " ambient-safe-mode" : (isPromo ? " compact-promo-mode" : ""));

  let displayVerdictLabel = "Verified Safe";
  let verdictEmoji = "🛡️";
  let riskLevelKey = "low";
  let riskLevelText = "LOW RISK";
  let simpleTitle = "Safe & Legitimate Email";
  let simpleLead = "No phishing lures or security risks found. This email appears authentic and safe to interact with.";
  let simpleTip = "You can open links and interact with this email normally.";

  if (verdict === "high_risk") {
    displayVerdictLabel = "High-Risk Scam / Phishing";
    verdictEmoji = "🔴";
    riskLevelKey = "high";
    riskLevelText = "HIGH RISK";
    simpleTitle = "⚠️ Warning: High-Risk Scam / Phishing";
    simpleLead = "Danger: This email shows strong signs of phishing, fake urgency, or credential theft designed to steal your account or money.";
    simpleTip = "Do NOT click any links or download attachments. We strongly recommend reporting it as spam.";
  } else if (verdict === "suspicious") {
    displayVerdictLabel = "Suspicious Email";
    verdictEmoji = "🟠";
    riskLevelKey = "med";
    riskLevelText = "SUSPICIOUS";
    simpleTitle = "Caution: Suspicious Signs Detected";
    simpleLead = "This email has warning signs (such as unusual links or unfamiliar sender domains). It may be trying to mislead you.";
    simpleTip = "Do not enter passwords, credit card info, or personal verification codes (OTPs).";
  } else if (verdict === "promo_clutter") {
    displayVerdictLabel = "Promotional Newsletter";
    verdictEmoji = "✨";
    riskLevelKey = "promo";
    riskLevelText = "PROMO";
    simpleTitle = "Promotional Newsletter";
    simpleLead = "Legitimate marketing newsletter with clean links and zero security threats.";
    simpleTip = "Use One-Click Unsubscribe to opt out directly.";
  }

  const qrData = data.qr || (window.__latestQrScanResult ? window.__latestQrScanResult : null);
  let qrScoreText = "NO QR DETECTED";
  let qrChipClass = "qr-none";
  let qrVerdictLabel = "NONE";
  let qrFlags = [];
  let qrPayload = "";
  let qrDefanged = "";
  let qrKind = "";
  let hasQrThreat = false;

  if (qrData) {
    const rawQrScore = Number(qrData.score !== undefined ? qrData.score : (qrData.risk_score || 0));
    const rawQrVerdict = String(qrData.verdict || qrData.legacy_verdict || "safe").toLowerCase();
    const isHigh = rawQrVerdict === "high_risk" || rawQrVerdict === "malicious" || rawQrScore >= 66;
    const isSuspicious = !isHigh && (rawQrVerdict === "suspicious" || rawQrScore >= 35);
    qrVerdictLabel = isHigh ? "HIGH RISK" : (isSuspicious ? "SUSPICIOUS" : "SAFE");
    qrScoreText = `${rawQrScore}/100 [ ${qrVerdictLabel} ]`;
    qrChipClass = isHigh ? "qr-high_risk" : (isSuspicious ? "qr-suspicious" : "qr-safe");
    qrFlags = qrData.flags || [];
    qrPayload = qrData.payload || "";
    qrDefanged = qrData.defanged || qrPayload;
    qrKind = qrData.payload_kind || "";
    if (isHigh || isSuspicious || rawQrScore > 0 || qrFlags.length > 0) {
      hasQrThreat = true;
    }
  }

  let authBadgeHtml = "";
  const authSummary = data.auth || (data.engine && data.engine.auth_status ? { status: data.engine.auth_status } : null);
  if (authSummary && authSummary.status) {
    if (authSummary.status === "spoof") {
      authBadgeHtml = `<span class="ratiod-tag tag-auth-spoof">⚠️ DKIM Spoof Warning</span>`;
    } else if (authSummary.status === "verified") {
      authBadgeHtml = `<span class="ratiod-tag tag-auth-verified">🔒 DKIM Verified</span>`;
    } else if (authSummary.status === "unverified") {
      authBadgeHtml = `<span class="ratiod-tag tag-auth-unverified">Auth: Unverified</span>`;
    }
  }

  let logoSrc = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3E%3Crect width='48' height='48' rx='10' fill='%23EA3E2B'/%3E%3Ctext x='50%25' y='55%25' dominant-baseline='middle' text-anchor='middle' fill='%23FFFFFF' font-size='28' font-weight='800' font-family='sans-serif'%3ER%3C/text%3E%3C/svg%3E";
  try {
    const ext = (typeof browser !== "undefined" && browser.runtime) ? browser
      : ((typeof chrome !== "undefined" && chrome.runtime) ? chrome : null);
    if (ext && typeof ext.runtime?.getURL === "function") {
      const url = ext.runtime.getURL("icons/icon48.png");
      if (url) logoSrc = url;
    } else if (typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.getURL === "function") {
      const url = chrome.runtime.getURL("icons/icon48.png");
      if (url) logoSrc = url;
    }
  } catch (e) {}

  container.innerHTML = `
    <div class="ratiod-header">
      <div class="ratiod-badge-group">
        <img class="ratiod-logo" src="${escapeHtml(logoSrc)}" alt="" width="22" height="22">
        <span class="ratiod-tag tag-${escapeHtml(verdict)}">${verdictEmoji} ${escapeHtml(displayVerdictLabel)}</span>
        ${isPromo
          ? `<button class="ratiod-btn ratiod-btn-unsub btn-highlight-unsub ratiod-header-action-btn" id="btn-header-unsub" type="button" title="One-Click Unsubscribe from this newsletter">✨ Unsubscribe</button>`
          : (verdict !== 'safe'
              ? `<button class="ratiod-header-action-btn btn-highlight-safe" id="btn-header-safe" data-feedback="safe" type="button" title="One-click: change tag to SAFE and submit feedback">🛡️ Mark as Safe</button>`
              : ''
            )
        }
        ${authBadgeHtml}
        <span class="ratiod-score ratiod-score-mail" title="Mail Security Risk Score"><span class="score-type-badge">Risk</span><span class="score-number">${escapeHtml(mailScore)}</span><span class="score-denom">/100</span></span>
        <span class="ratiod-score ratiod-score-qr ${escapeHtml(qrChipClass)}" id="banner-qr-score" style="display: ${hasQrThreat ? 'inline-flex' : 'none'};" title="QR Security Code Risk Score"><span class="score-type-badge">QR</span><span id="banner-qr-score-val">${escapeHtml(qrScoreText)}</span></span>
      </div>
      <div class="ratiod-header-actions">
        <button class="ratiod-iconbtn" id="btn-collapse" type="button" aria-expanded="${(isSafe || isPromo) ? 'false' : 'true'}" aria-controls="ratiod-body" title="${(isSafe || isPromo) ? 'Expand analysis' : 'Collapse analysis'}">
          <span aria-hidden="true">${(isSafe || isPromo) ? '&#9662;' : '&#9652;'}</span><span class="sr-only">Collapse analysis</span>
        </button>
        <button class="ratiod-iconbtn" id="btn-dismiss" type="button" title="Dismiss Ratio'd for this email">
          <span aria-hidden="true">&#10005;</span><span class="sr-only">Dismiss Ratio'd</span>
        </button>
      </div>
    </div>

    <div class="ratiod-body ${(isSafe || isPromo) ? 'collapsed' : ''}" id="ratiod-body">
      <div class="ratiod-summary-card">
        <div class="ratiod-summary-header">
          <span class="ratiod-summary-icon" aria-hidden="true">${verdictEmoji}</span>
          <div class="ratiod-summary-content">
            <div class="ratiod-summary-title">${escapeHtml(simpleTitle)}</div>
            <div class="ratiod-summary-lead">${escapeHtml(simpleLead)}</div>
            ${simpleTip ? `<div class="ratiod-summary-tip"><strong>💡 Quick Tip:</strong> ${escapeHtml(simpleTip)}</div>` : ''}
          </div>
        </div>
        <div class="ratiod-explanation"><span class="ratiod-explanation-label">Analysis:</span> ${escapeHtml(explanation)}</div>
        <div class="ratiod-feedback-strip" id="ratiod-feedback-strip">
          <div class="ratiod-feedback-label-box">
            <span class="ratiod-feedback-prompt">Help improve Ratio'd:</span>
            <span class="ratiod-feedback-sub">Change classification with one click:</span>
          </div>
          <div class="ratiod-feedback-chips">
            <button class="ratiod-chip-btn ${verdict === 'safe' ? 'chip-active' : ''}" type="button" data-feedback="safe" title="One-click: Mark as Safe">🛡️ Safe</button>
            <button class="ratiod-chip-btn ${verdict === 'promo_clutter' ? 'chip-active' : ''}" type="button" data-feedback="promo" title="One-click: Mark as Newsletter">✨ Newsletter</button>
            <button class="ratiod-chip-btn ${verdict === 'suspicious' ? 'chip-active' : ''}" type="button" data-feedback="suspicious" title="One-click: Mark as Suspicious">🟠 Suspicious</button>
            <button class="ratiod-chip-btn ${verdict === 'high_risk' ? 'chip-active' : ''}" type="button" data-feedback="unsafe" title="One-click: Mark as Phishing">🔴 Phishing</button>
          </div>
        </div>
        <div class="ratiod-feedback-toast" id="ratiod-feedback-toast" style="display:none;" role="status" aria-live="polite"></div>
      </div>

      <div class="ratiod-actions">
        <button class="ratiod-btn ratiod-btn-primary" id="toggle-drawer" type="button" aria-expanded="false" aria-controls="analysis-drawer">See Details ▾</button>
        ${verdict === 'safe'
          ? '<button class="ratiod-btn ratiod-btn-feedback btn-highlight-unsafe" id="btn-quick-feedback" data-feedback="unsafe" type="button" title="Mark this email as unsafe and submit feedback">⚠️ Mark as Unsafe</button>'
          : '<button class="ratiod-btn ratiod-btn-feedback btn-highlight-safe" id="btn-quick-feedback" data-feedback="safe" type="button" title="Mark this email as safe and submit feedback">🛡️ Mark as Safe</button>'
        }
        <button class="ratiod-btn ratiod-btn-unsub ${verdict === 'promo_clutter' ? 'btn-highlight-unsub' : ''}" id="btn-one-unsub" type="button">✨ Unsubscribe</button>
        <button class="ratiod-btn ratiod-btn-spam ${verdict === 'high_risk' ? 'btn-highlight-spam' : ''}" id="btn-move-spam" type="button">🚫 Report Spam</button>
      </div>

      <div class="ratiod-drawer" id="analysis-drawer" role="region" aria-label="Full Ratio'd analysis">
        <div class="drawer-section-title">✉️ MAIL SECURITY ANALYSIS</div>
        <div class="drawer-sub-heading">Mail Risk Score: ${escapeHtml(mailScore)}/100 &bull; Status: ${escapeHtml(displayVerdictLabel)}</div>
        <div id="drawer-mail-flags">
          ${flags.length > 0 ? flags.map(f => `
            <div class="flag-item">
              <span class="flag-span">${escapeHtml(f.span)}</span> &mdash; ${escapeHtml(f.reason)}
              ${(f.span && (f.span.includes("http") || f.span.includes("bit.ly") || f.span.includes("."))) ? `<button type="button" class="flag-peek-btn" data-peek-url="${escapeHtml(f.span)}">&#128269; Safe Peek</button><div class="flag-peek-res" style="display:none;"></div>` : ''}
            </div>
          `).join('') : '<div class="flag-item">No explicit email threat rules triggered.</div>'}
        </div>

        <details class="ratiod-telemetry-details" style="margin-top: 14px;">
          <summary class="drawer-section-title" style="cursor:pointer;list-style:none;display:flex;align-items:center;justify-content:space-between;">
            <span>⚙️ ADVANCED VEGAML PHYSICS TELEMETRY</span>
            <span style="font-size:10px;font-weight:600;opacity:0.7;">▾</span>
          </summary>
          <div id="drawer-vegaml-section" style="margin-top:8px;">
            <div class="flag-item" style="font-family:'JetBrains Mono',monospace;font-size:11px;line-height:1.6;">
              <div><strong>MODEL:</strong> VegaML 64-D Hamiltonian Dynamics (${escapeHtml(vegaSource)})</div>
              <div><strong>THREAT BASIN:</strong> <span class="flag-span">${escapeHtml(vegaThreatBasin)}</span> &bull; <strong>CONVERGENCE:</strong> ${escapeHtml(vegaConvergence)}</div>
              <div><strong>90% CONFORMAL PREDICTION SET:</strong> [ ${escapeHtml(vegaConformalSet)} ]</div>
              <div><strong>THERMODYNAMICS:</strong> Calibrated Temp &tau; = ${escapeHtml(vegaTemp)} &bull; Residual Kinetic E = ${escapeHtml(vegaKinetic)}</div>
            </div>
          </div>
        </details>

        <div class="drawer-section-title" style="margin-top: 14px;">📱 QR Security Code Analysis</div>
        <div id="drawer-qr-section">
          ${qrData ? `
            <div class="qr-banner-card card-${escapeHtml(qrChipClass.replace('qr-', ''))}">
              <div class="qr-banner-card-header">
                <div><strong>QR Code Status:</strong> <span class="ratiod-tag tag-${escapeHtml(qrChipClass.replace('qr-', ''))}">${escapeHtml(qrVerdictLabel)}</span></div>
                <span class="ratiod-score">QR Risk Score: ${escapeHtml(qrData.score !== undefined ? qrData.score : 0)}/100</span>
              </div>
              <div class="qr-banner-payload-label">Decoded QR Payload ${qrKind ? `(${escapeHtml(qrKind)})` : ''}:</div>
              <code class="qr-banner-code">${escapeHtml(qrDefanged || qrPayload)}</code>
              ${qrPayload ? `<button type="button" class="flag-peek-btn" data-peek-url="${escapeHtml(qrPayload)}">&#128269; Safe Peek QR Link</button><div class="flag-peek-res" style="display:none;"></div>` : ''}
              <div style="font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;margin-top:8px;">Detected QR Code Signals:</div>
              ${qrFlags.length > 0 ? qrFlags.map(f => `
                <div class="flag-item" style="margin-top:4px;">
                  <span class="flag-span">${escapeHtml(f.span)}</span> &mdash; ${escapeHtml(f.reason)}
                </div>
              `).join('') : '<div class="flag-item" style="margin-top:4px;">No suspicious QR code patterns detected.</div>'}
            </div>
          ` : `
            <div class="flag-item" id="qr-empty-msg">No QR codes detected in this message. Email images are monitored for embedded QR threats.</div>
          `}
        </div>

        <div class="drawer-section-title" style="margin-top: 14px;">📋 Recommended Actions</div>
        <ul class="checklist-list">
          ${nextSteps.map(step => `<li><strong>&bull;</strong> ${escapeHtml(step)}</li>`).join('')}
        </ul>

        <div class="privacy-footnote">
          &#10003; Real-time PII redaction active: ${escapeHtml(privacy.phones_masked || 0)} phone(s), ${escapeHtml(privacy.emails_masked || 0)} email(s), ${escapeHtml(privacy.otp_masked || 0)} code(s) &mdash; ${escapeHtml(totalMasked)} item(s) masked before analysis. Zero message text stored.
        </div>
      </div>
    </div>

    <div class="ratiod-credit">
      <span>Ratio'd &middot; developed by
        <a class="ratiod-cred" href="https://github.com/VedxntDev" target="_blank" rel="noopener noreferrer">Vedant</a>
      </span>
    </div>
  `;

  shadowRoot.appendChild(container);

  const insertAnchor = targetElement.closest(".ii.gt") || targetElement;
  if (insertAnchor && insertAnchor.parentElement) {
    insertAnchor.parentElement.insertBefore(host, insertAnchor);
  } else if (targetElement.parentElement) {
    targetElement.parentElement.insertBefore(host, targetElement);
  } else {
    targetElement.prepend(host);
  }

  const toggleBtn = shadowRoot.getElementById("toggle-drawer");
  const unsubBtn = shadowRoot.getElementById("btn-one-unsub");
  const headerUnsubBtn = shadowRoot.getElementById("btn-header-unsub");
  const spamBtn = shadowRoot.getElementById("btn-move-spam");
  const drawer = shadowRoot.getElementById("analysis-drawer");
  const collapseBtn = shadowRoot.getElementById("btn-collapse");
  const dismissBtn = shadowRoot.getElementById("btn-dismiss");
  const body = shadowRoot.getElementById("ratiod-body");

  if (headerUnsubBtn && unsubBtn) {
    headerUnsubBtn.addEventListener("click", () => {
      unsubBtn.click();
    });
  }

  if (toggleBtn && drawer) {
    toggleBtn.addEventListener("click", () => {
      const open = drawer.classList.toggle("open");
      toggleBtn.setAttribute("aria-expanded", String(open));
      toggleBtn.textContent = open ? "Hide Details ▴" : "See Details ▾";
    });
  }

  // Collapse: keep the score badge on screen, hide the advice and actions.
  if (collapseBtn && body) {
    collapseBtn.addEventListener("click", () => {
      const collapsed = body.classList.toggle("collapsed");
      collapseBtn.setAttribute("aria-expanded", String(!collapsed));
      collapseBtn.title = collapsed ? "Expand analysis" : "Collapse analysis";
      collapseBtn.querySelector("[aria-hidden]").innerHTML = collapsed ? "&#9662;" : "&#9652;";
      if (container.classList.contains("ambient-safe-mode")) {
        container.classList.toggle("expanded", !collapsed);
      }
    });
  }

  // Dismiss: the user is not going to read this banner for this message, and a
  // banner they cannot get rid of trains people to ignore every banner.
  if (dismissBtn) {
    dismissBtn.addEventListener("click", () => {
      if (host.parentElement) host.parentElement.removeChild(host);
    });
  }

  // User Feedback Overrides & Telemetry
  function applyUserFeedback(feedbackType, originBtn) {
    const toast = shadowRoot.getElementById("ratiod-feedback-toast");
    const headerTag = shadowRoot.querySelector(".ratiod-tag");
    const mailScoreVal = shadowRoot.querySelector(".ratiod-score-mail");
    const explanationEl = shadowRoot.querySelector(".ratiod-explanation");
    const feedbackChips = shadowRoot.querySelectorAll(".ratiod-chip-btn");
    const quickFeedbackBtn = shadowRoot.getElementById("btn-quick-feedback");

    feedbackChips.forEach(chip => {
      if (chip.getAttribute("data-feedback") === feedbackType) {
        chip.classList.add("chip-active");
      } else {
        chip.classList.remove("chip-active");
      }
    });

    if (toast) {
      toast.style.display = "block";
      toast.textContent = `✓ Feedback saved: Marked as ${feedbackType.toUpperCase()}. Thanks for helping Ratio'd learn!`;
    }

    if (!prefersReducedMotion()) {
      playUnsubscribeSparkleSound();
      if (feedbackType === "safe" && originBtn) {
        launchGlitterBurst(shadowRoot, originBtn);
      }
    }

    if (headerTag) {
      if (feedbackType === "safe") {
        headerTag.className = "ratiod-tag tag-safe tag-user-safe";
        headerTag.textContent = "🛡️ User Override: Safe";
      } else if (feedbackType === "suspicious") {
        headerTag.className = "ratiod-tag tag-suspicious tag-user-suspicious";
        headerTag.textContent = "🟠 User Override: Suspicious";
      } else if (feedbackType === "promo") {
        headerTag.className = "ratiod-tag tag-promo_clutter tag-user-promo";
        headerTag.textContent = "🏷️ User Override: Promo";
      } else if (feedbackType === "unsafe" || feedbackType === "high_risk") {
        headerTag.className = "ratiod-tag tag-high_risk tag-user-unsafe";
        headerTag.textContent = "⚠️ User Override: Unsafe";
      }
    }

    if (container) {
      container.className = "ratiod-container theme-" + (feedbackType === "promo" ? "promo_clutter" : (feedbackType === "suspicious" ? "suspicious" : (feedbackType === "safe" ? "safe" : "high_risk")));
    }

    if (mailScoreVal) {
      const newScore = feedbackType === "safe" ? 0 : (feedbackType === "promo" ? 25 : (feedbackType === "suspicious" ? 45 : 85));
      const newLevelKey = feedbackType === "safe" ? "low" : (feedbackType === "promo" ? "promo" : (feedbackType === "suspicious" ? "med" : "high"));
      const newLevelText = feedbackType === "safe" ? "LOW RISK" : (feedbackType === "promo" ? "PROMO / CLUTTER" : (feedbackType === "suspicious" ? "SUSPICIOUS" : "HIGH RISK"));
      mailScoreVal.innerHTML = `<span class="score-type-badge">MAIL</span><span class="score-number">${newScore}</span><span class="score-denom">/100</span> <span class="score-level-badge level-${newLevelKey}">${newLevelText}</span>`;
    }

    if (explanationEl) {
      const explType = feedbackType === "safe" ? "safe" : (feedbackType === "promo" ? "promotional newsletter" : (feedbackType === "suspicious" ? "suspicious" : "unsafe / phishing"));
      explanationEl.innerHTML = `<span class="ratiod-explanation-label">User Feedback:</span> Marked as ${explType} by user. Local override applied.`;
    }

    const headerOverrideBtn = shadowRoot.getElementById("btn-header-safe") || shadowRoot.getElementById("btn-header-unsafe");
    if (headerOverrideBtn) {
      if (feedbackType === "safe") {
        headerOverrideBtn.id = "btn-header-unsafe";
        headerOverrideBtn.className = "ratiod-header-action-btn btn-highlight-unsafe";
        headerOverrideBtn.setAttribute("data-feedback", "unsafe");
        headerOverrideBtn.textContent = "⚠️ Mark as Unsafe";
      } else {
        headerOverrideBtn.id = "btn-header-safe";
        headerOverrideBtn.className = "ratiod-header-action-btn btn-highlight-safe";
        headerOverrideBtn.setAttribute("data-feedback", "safe");
        headerOverrideBtn.textContent = "🛡️ Mark as Safe";
      }
    }

    if (quickFeedbackBtn) {
      if (feedbackType === "safe") {
        quickFeedbackBtn.className = "ratiod-btn ratiod-btn-feedback btn-highlight-unsafe";
        quickFeedbackBtn.setAttribute("data-feedback", "unsafe");
        quickFeedbackBtn.textContent = "⚠️ Mark as Unsafe";
      } else {
        quickFeedbackBtn.className = "ratiod-btn ratiod-btn-feedback btn-highlight-safe";
        quickFeedbackBtn.setAttribute("data-feedback", "safe");
        quickFeedbackBtn.textContent = "🛡️ Mark as Safe";
      }
    }

    // Persist override to chrome.storage.local
    const mappedVerdict = feedbackType === "safe"
      ? "safe"
      : (feedbackType === "suspicious"
        ? "suspicious"
        : (feedbackType === "promo"
          ? "promo_clutter"
          : "high_risk"));
    const mappedScore = feedbackType === "safe"
      ? 0
      : (feedbackType === "suspicious"
        ? 45
        : (feedbackType === "promo"
          ? 25
          : 85));

    const rawSender = (data.emailMeta && (data.emailMeta.senderAddress || data.emailMeta.from)) || "";
    const cleanSender = extractCleanEmail(rawSender);
    const cleanDomain = extractEmailDomain(cleanSender);

    const keysToOverride = [];
    if (cleanSender) {
      keysToOverride.push(cleanSender);
      keysToOverride.push("sender:" + cleanSender);
    }
    if (data.emailMeta && data.emailMeta.subject) keysToOverride.push(data.emailMeta.subject);
    if (data.emailMeta && data.emailMeta.from) keysToOverride.push(data.emailMeta.from);
    if (data.cacheKey) keysToOverride.push(data.cacheKey);
    const hash = window.location.hash ? window.location.hash.replace(/^#/, "") : "";
    if (hash) keysToOverride.push(hash);

    try {
      const ext = (typeof browser !== "undefined" && browser.storage && browser.storage.local) ? browser.storage.local
        : ((typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) ? chrome.storage.local : null);
      if (ext) {
        ext.get(["ratiod_user_overrides", "ratiod_sender_learning"], (res) => {
          const overrides = (res && res.ratiod_user_overrides) || {};
          const senderLearning = (res && res.ratiod_sender_learning) || {};
          const record = {
            verdict: mappedVerdict,
            score: mappedScore,
            feedback: feedbackType,
            sender: cleanSender || null,
            domain: cleanDomain || null,
            timestamp: Date.now()
          };
          for (const k of keysToOverride) {
            if (k) overrides[String(k).trim().toLowerCase()] = record;
          }
          if (cleanSender) {
            senderLearning[cleanSender] = {
              sender: cleanSender,
              domain: cleanDomain,
              verdict: mappedVerdict,
              score: mappedScore,
              feedback: feedbackType,
              userExplicit: true,
              updatedAt: Date.now()
            };
          }
          ext.set({
            ratiod_user_overrides: overrides,
            ratiod_sender_learning: senderLearning
          });
        });
      }
    } catch (e) {}

    // Dispatch global event for content script to synchronize inbox list view pills
    try {
      window.dispatchEvent(new CustomEvent("ratiod:user-feedback", {
        detail: {
          verdict: mappedVerdict,
          score: mappedScore,
          feedback: feedbackType,
          sender: cleanSender,
          domain: cleanDomain,
          keys: keysToOverride
        }
      }));
    } catch (e) {}

    // Transmit feedback to backend API
    const feedbackPayload = {
      feedback: feedbackType,
      originalVerdict: verdict,
      originalScore: mailScore,
      sender: (data.emailMeta && data.emailMeta.from) || null,
      subject: (data.emailMeta && data.emailMeta.subject) || null,
      flags: (flags || []).map(f => (f && f.reason) || String(f || "")),
      timestamp: new Date().toISOString()
    };

    const endpoints = ["http://127.0.0.1:3000/feedback", "https://ratio-d.vercel.app/api/feedback", "https://www.ratiod.online/api/feedback"];
    for (const ep of endpoints) {
      try {
        fetch(ep, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(feedbackPayload)
        }).catch(() => {});
      } catch (err) {}
    }
  }

  const headerActionBtn = shadowRoot.getElementById("btn-header-safe") || shadowRoot.getElementById("btn-header-unsafe");
  if (headerActionBtn) {
    headerActionBtn.addEventListener("click", () => {
      const fb = headerActionBtn.getAttribute("data-feedback") || "safe";
      applyUserFeedback(fb, headerActionBtn);
    });
  }

  const quickFeedbackBtn = shadowRoot.getElementById("btn-quick-feedback");
  if (quickFeedbackBtn) {
    quickFeedbackBtn.addEventListener("click", () => {
      const fb = quickFeedbackBtn.getAttribute("data-feedback") || "safe";
      applyUserFeedback(fb, quickFeedbackBtn);
    });
  }

  shadowRoot.querySelectorAll(".ratiod-chip-btn").forEach(chip => {
    chip.addEventListener("click", () => {
      const fb = chip.getAttribute("data-feedback") || "safe";
      applyUserFeedback(fb, chip);
    });
  });

  function bindSafePeek(root) {
    root.querySelectorAll(".flag-peek-btn").forEach((btn) => {
      if (btn.__bound) return;
      btn.__bound = true;
      btn.addEventListener("click", async () => {
        const targetUrl = btn.getAttribute("data-peek-url");
        const resContainer = btn.nextElementSibling;
        if (!targetUrl || !resContainer) return;

        btn.disabled = true;
        btn.textContent = "Tracing...";
        resContainer.style.display = "block";
        resContainer.textContent = "Tracing redirect route...";

        const tryEndpoints = ["http://127.0.0.1:3000/unmask", "https://ratio-d.vercel.app/api/unmask"];
        let unmasked = null;
        for (const ep of tryEndpoints) {
          try {
            const resp = await fetch(ep, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ url: targetUrl })
            });
            if (resp.ok) {
              unmasked = await resp.json();
              break;
            }
          } catch {}
        }

        if (unmasked) {
          const dest = escapeHtml(unmasked.finalDomain || unmasked.finalUrl);
          const v = escapeHtml(unmasked.risk?.verdict?.toUpperCase() || 'SAFE');
          const sc = escapeHtml(unmasked.risk?.score || 0);
          const vColor = unmasked.risk?.verdict === 'high_risk' ? '#EA3E2B' : '#8A8B5C';
          resContainer.innerHTML = `
            <strong>Safe Peek:</strong> ${escapeHtml(unmasked.hops)} hop(s) &rarr; Destination: <strong>${dest}</strong><br>
            Risk Verdict: <span style="font-weight:800;color:${vColor}">${v}</span> (Score: ${sc}/100)
          `;
        } else {
          resContainer.textContent = "Could not trace route (offline or unresolvable).";
        }
        btn.disabled = false;
        btn.textContent = "🔍 Safe Peek";
      });
    });
  }

  // Safe Peek Zero-Execution Link Redirect Tracer
  bindSafePeek(shadowRoot);

  // Helper to decode Google redirect URLs
  function resolveTargetUrl(rawUrl) {
    if (!rawUrl) return "";
    try {
      if (rawUrl.includes("google.com/url?") || rawUrl.includes("google.com/url%3F")) {
        const m = rawUrl.match(/[?&]q=([^&]+)/);
        if (m && m[1]) return decodeURIComponent(m[1]);
      }
    } catch (e) {}
    return rawUrl;
  }

  // Helper to dispatch native MouseEvent click that bypasses Chrome content script popup blocker
  function openUrlInTab(targetUrl) {
    const cleanUrl = resolveTargetUrl(targetUrl);
    if (!cleanUrl) return false;

    if (cleanUrl.startsWith("mailto:")) {
      window.location.href = cleanUrl;
      return true;
    }

    try {
      const tempAnchor = document.createElement("a");
      tempAnchor.href = cleanUrl;
      tempAnchor.target = "_blank";
      tempAnchor.rel = "noopener noreferrer";
      tempAnchor.style.display = "none";
      (document.body || document.documentElement).appendChild(tempAnchor);

      const clickEvt = new MouseEvent("click", {
        bubbles: true,
        cancelable: true,
        view: window
      });
      tempAnchor.dispatchEvent(clickEvt);

      setTimeout(() => {
        try { tempAnchor.remove(); } catch (e) {}
      }, 1000);
      return true;
    } catch (e) {
      try {
        window.open(cleanUrl, "_blank");
        return true;
      } catch (err) {
        return false;
      }
    }
  }

  // Helper to dispatch DOM click events to an element
  function dispatchElementClick(el) {
    if (!el) return false;
    try {
      el.click();
    } catch (e) {}

    try {
      const opts = { bubbles: true, cancelable: true, view: window, buttons: 1 };
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
      return true;
    } catch (e) {
      return false;
    }
  }

  // Robust One-Click Unsubscribe Click Handler + Glitter Burst + Sparkle Chime Sound
  if (unsubBtn) {
    unsubBtn.addEventListener("click", () => {
      // 1. Play Web Audio API Sparkle Chime Sound Effect & Glitter Burst
      if (!prefersReducedMotion()) {
        playUnsubscribeSparkleSound();
        launchGlitterBurst(shadowRoot, unsubBtn);
      }

      // 2. Multi-Strategy Unsubscribe Handler
      let unsubSuccess = false;

      // Strategy A: Gmail Native Header Unsubscribe Action
      const headerArea = document.querySelector(".gE, .ha, .gD, .iv, .adn, [role='main']") || document;
      const nativeCandidates = Array.from(headerArea.querySelectorAll(
        '.aG, span.aG, div.aG, a.aG, [data-tooltip*="Unsubscribe" i], [aria-label*="Unsubscribe" i], [aria-label*="Opt out" i], [act="10"]'
      )).filter(el => {
        if (el.closest('.ratiod-shadow-host') || el === unsubBtn || unsubBtn.contains(el)) return false;
        if (el.closest('.a3s')) return false;
        return true;
      });

      if (nativeCandidates.length > 0) {
        const candidate = nativeCandidates[0];
        const clickable = (candidate.matches && candidate.matches('a, button, [role="button"], [role="link"], [act]'))
          ? candidate
          : (candidate.querySelector ? (candidate.querySelector('a, button, [role="button"], [role="link"], [act]') || candidate) : candidate);

        function updateUnsubButton(txt, bg) {
          unsubBtn.textContent = txt;
          if (bg) unsubBtn.style.backgroundColor = bg;
          const hBtn = shadowRoot.getElementById("btn-header-unsub");
          if (hBtn) {
            hBtn.textContent = txt;
            if (bg) hBtn.style.backgroundColor = bg;
          }
        }

        try {
          dispatchElementClick(clickable);
          unsubSuccess = true;
          updateUnsubButton("✨ Unsubscribed & Cleaned!", "#10B981");

          // Auto-confirm Gmail's native popup dialog if it opens
          setTimeout(() => {
            const dialogConfirmBtn = document.querySelector(
              'div[role="dialog"] button[name="ok"], div[role="dialog"] button[aria-label*="Unsubscribe" i], div[role="dialog"] .T-I-ATL, div[role="dialog"] button:not([aria-label*="Cancel" i])'
            );
            if (dialogConfirmBtn) {
              dispatchElementClick(dialogConfirmBtn);
            }
          }, 350);
        } catch (e) {
          console.log("[NATIVE UNSUB ERROR]", e);
        }
      }

      // Strategy B: Body Anchor Links (Unsubscribe / Opt-out / Manage Preferences)
      if (!unsubSuccess) {
        const bodyElem = document.querySelector('.a3s.aiL, .a3s, .ii.gt, .adn.ads, [role="main"]') || document;
        const anchors = Array.from(bodyElem.querySelectorAll('a')).filter(a => {
          if (a.closest('.ratiod-shadow-host')) return false;
          const href = (a.href || a.getAttribute('href') || a.getAttribute('data-saferedirecturl') || '').toLowerCase();
          const txt = (a.innerText || a.textContent || a.getAttribute('aria-label') || '').toLowerCase();
          
          return (
            href.includes('unsubscribe') || href.includes('optout') || href.includes('opt-out') ||
            href.includes('email-preferences') || href.includes('manage-subscription') || href.includes('sub_unsub') ||
            txt.includes('unsubscribe') || txt.includes('opt out') || txt.includes('opt-out') ||
            txt.includes('manage preferences') || txt.includes('email preferences') || txt.includes('cancel subscription') ||
            txt.includes('remove me')
          );
        });

        if (anchors.length > 0) {
          const targetAnchor = anchors[0];
          const rawUrl = targetAnchor.href || targetAnchor.getAttribute('href') || targetAnchor.getAttribute('data-saferedirecturl');

          dispatchElementClick(targetAnchor);

          if (rawUrl) {
            openUrlInTab(rawUrl);
          }

          unsubSuccess = true;
          updateUnsubButton("✨ Unsubscribe Link Opened!", "#10B981");
        }
      }

      // Strategy C: Mailto Fallback
      if (!unsubSuccess) {
        const bodyText = (document.querySelector('.a3s') || document.body).innerText || '';
        const mailtoMatch = bodyText.match(/mailto:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i);
        if (mailtoMatch) {
          window.location.href = `mailto:${mailtoMatch[1]}?subject=Unsubscribe`;
          unsubSuccess = true;
          updateUnsubButton("✨ Unsubscribe Sent!", "#10B981");
        }
      }

      if (!unsubSuccess) {
        updateUnsubButton("⚠️ No Unsubscribe Link Found", "#DC2626");
        setTimeout(() => {
          updateUnsubButton("✨ Unsubscribe", "");
        }, 3000);
      }
    });
  }

  if (spamBtn) {
    spamBtn.addEventListener("click", () => {
      const gmailSpamBtn = document.querySelector(
        'div[aria-label*="Spam"], div[act="9"], div[data-tooltip*="Spam"], button[aria-label*="Spam"]'
      );
      if (gmailSpamBtn) {
        gmailSpamBtn.click();
        spamBtn.textContent = "🚫 Sent to Spam";
        spamBtn.style.backgroundColor = "#10B981";
      } else {
        spamBtn.textContent = "🚫 Flagged as Spam";
        spamBtn.style.backgroundColor = "#10B981";
      }
        spamBtn.style.backgroundColor = "#8A8B5C";
      }
    });
  }
}

function updateRatiodBannerQr(qrResult) {
  if (!qrResult) return;
  window.__latestQrScanResult = qrResult;
  const host = document.getElementById("ratiod-banner-host");
  if (!host || !host.shadowRoot) return;
  const root = host.shadowRoot;

  const rawQrScore = Number(qrResult.score !== undefined ? qrResult.score : (qrResult.risk_score || 0));
  const rawQrVerdict = String(qrResult.verdict || qrResult.legacy_verdict || "safe").toLowerCase();
  const isHigh = rawQrVerdict === "high_risk" || rawQrVerdict === "malicious" || rawQrScore >= 66;
  const isSuspicious = !isHigh && (rawQrVerdict === "suspicious" || rawQrScore >= 35);
  const qrVerdictUpper = isHigh ? "HIGH RISK" : (isSuspicious ? "SUSPICIOUS" : "SAFE");
  const qrChipClass = isHigh ? "qr-high_risk" : (isSuspicious ? "qr-suspicious" : "qr-safe");
  const cardBorderClass = isHigh ? "card-high_risk" : (isSuspicious ? "card-suspicious" : "card-safe");

  // 1. Update QR Score Pill in header
  const qrPill = root.getElementById("banner-qr-score");
  const qrPillVal = root.getElementById("banner-qr-score-val");
  if (qrPill && qrPillVal) {
    qrPillVal.textContent = `${rawQrScore}/100 [ ${qrVerdictUpper} ]`;
    qrPill.className = `ratiod-score ratiod-score-qr ${qrChipClass}`;
  }

  // 2. Elevate overall banner verdict if QR threat is higher
  if (isHigh) {
    const verdictTag = root.querySelector(".ratiod-tag");
    if (verdictTag && !verdictTag.classList.contains("tag-high_risk")) {
      verdictTag.className = "ratiod-tag tag-high_risk";
      verdictTag.textContent = "[ 🔴 HIGH RISK (QR PHISH) ]";
    }
    const container = root.querySelector(".ratiod-container");
    if (container) {
      container.className = "ratiod-container theme-high_risk";
    }
    const explanationEl = root.querySelector(".ratiod-explanation");
    if (explanationEl && !explanationEl.textContent.includes("QR CODE SECURITY ALERT")) {
      const alertStrong = document.createElement("strong");
      alertStrong.textContent = "[ ⚠️ QR CODE SECURITY ALERT ]: ";
      const alertText = document.createTextNode("Quishing payload detected in email image. ");
      explanationEl.prepend(alertStrong, alertText);
    }
  }

  // 3. Update QR section in drawer
  const qrSection = root.getElementById("drawer-qr-section");
  if (qrSection) {
    const defanged = qrResult.defanged || qrResult.payload || "";
    const payload = qrResult.payload || "";
    const kind = qrResult.payload_kind || "";
    const flags = qrResult.flags || [];

    let flagsHtml = '<div class="flag-item" style="margin-top:4px;">No suspicious QR code patterns detected.</div>';
    if (flags.length > 0) {
      flagsHtml = flags.map(f => `
        <div class="flag-item" style="margin-top:4px;">
          <span class="flag-span">${escapeHtml(f.span)}</span> &mdash; ${escapeHtml(f.reason)}
        </div>
      `).join('');
    }

    const peekBtnHtml = payload ? `<button type="button" class="flag-peek-btn" data-peek-url="${escapeHtml(payload)}">[ &#128269; Safe Peek QR Link ]</button><div class="flag-peek-res" style="display:none;"></div>` : '';

    qrSection.innerHTML = `
      <div class="qr-banner-card ${cardBorderClass}">
        <div class="qr-banner-card-header">
          <div><strong>QR CODE VERDICT:</strong> <span class="ratiod-tag tag-${isHigh ? 'high_risk' : (isSuspicious ? 'suspicious' : 'safe')}">[ ${escapeHtml(qrVerdictUpper)} ]</span></div>
          <span class="ratiod-score">QR RISK SCORE: ${escapeHtml(rawQrScore)}/100</span>
        </div>
        <div class="qr-banner-payload-label">DECODED QR PAYLOAD ${kind ? `(${escapeHtml(kind)})` : ''}:</div>
        <code class="qr-banner-code">${escapeHtml(defanged)}</code>
        ${peekBtnHtml}
        <div style="font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;margin-top:8px;">DETECTED QR CODE SIGNALS:</div>
        ${flagsHtml}
      </div>
    `;

    // Re-bind Safe Peek on newly added QR peek button
    root.querySelectorAll(".flag-peek-btn").forEach((btn) => {
      if (btn.__bound) return;
      btn.__bound = true;
      btn.addEventListener("click", async () => {
        const targetUrl = btn.getAttribute("data-peek-url");
        const resContainer = btn.nextElementSibling;
        if (!targetUrl || !resContainer) return;

        btn.disabled = true;
        btn.textContent = "Tracing...";
        resContainer.style.display = "block";
        resContainer.textContent = "Tracing redirect route...";

        const tryEndpoints = ["http://127.0.0.1:3000/unmask", "https://ratio-d.vercel.app/api/unmask"];
        let unmasked = null;
        for (const ep of tryEndpoints) {
          try {
            const resp = await fetch(ep, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ url: targetUrl })
            });
            if (resp.ok) {
              unmasked = await resp.json();
              break;
            }
          } catch {}
        }

        if (unmasked) {
          const dest = escapeHtml(unmasked.finalDomain || unmasked.finalUrl);
          const v = escapeHtml(unmasked.risk?.verdict?.toUpperCase() || 'SAFE');
          const sc = escapeHtml(unmasked.risk?.score || 0);
          const vColor = unmasked.risk?.verdict === 'high_risk' ? '#EA3E2B' : '#8A8B5C';
          resContainer.innerHTML = `
            <strong>Safe Peek:</strong> ${escapeHtml(unmasked.hops)} hop(s) &rarr; Destination: <strong>${dest}</strong><br>
            Risk Verdict: <span style="font-weight:800;color:${vColor}">${v}</span> (Score: ${sc}/100)
          `;
        } else {
          resContainer.textContent = "Could not trace route (offline or unresolvable).";
        }
        btn.disabled = false;
        btn.textContent = "🔍 Safe Peek";
      });
    });
  }
}

window.injectRatiodBanner = injectRatiodBanner;
window.updateRatiodBannerQr = updateRatiodBannerQr;
