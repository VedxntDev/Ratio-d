/**
 * Deterministic Channel-Aware Rule Engine for Ratio'd
 * Implements Homoglyph Normalization, Levenshtein Distance Brand Check,
 * Subdomain Brand-Stuffing Detection, and Urgency + Credential Combo Scoring.
 */

const KNOWN_BRANDS = [
  "microsoft",
  "google",
  "apple",
  "amazon",
  "paypal",
  "netflix",
  "bankofamerica",
  "chase",
  "wellsfargo",
  "stripe",
  "github",
  "linkedin",
  "usps",
  "fedex",
  "dhl",
  "ups",
  "facebook",
  "instagram",
  "twitter",
  "spotify",
  "dropbox",
  "coinbase",
  "binance",
  "kraken",
  // Brands added after running an external scam corpus through the engine. These
  // are impersonation targets seen in the wild that the original list missed
  // entirely - the engine was blind to all of them.
  "singtel",
  "grab",
  "metamask",
  "iras",
  "visa",
  "mastercard",
  "singpost",
  "singaporepost",
  "shopify"
];

/**
 * Brands shorter than this are never matched by substring or edit-distance.
 * A 1-3 character brand ("x", "ups", "dhl") matches by accident far too often —
 * e.g. an "x" anywhere in the domain made "example.com" look like brand
 * impersonation. Short brands are dropped rather than risk false positives.
 */
const MIN_BRAND_LEN = 4;
const SHORT_CARRIER_BRANDS = new Set(["dhl", "ups"]);
const MATCHABLE_BRANDS = KNOWN_BRANDS.filter((b) => b.length >= MIN_BRAND_LEN || SHORT_CARRIER_BRANDS.has(b));

const OFFICIAL_BRAND_DOMAINS = {
  microsoft: ["microsoft.com", "office.com", "live.com", "outlook.com", "microsoftonline.com", "accountprotection.microsoft.com"],
  google: ["google.com", "gmail.com", "accounts.google.com"],
  apple: ["apple.com", "icloud.com"],
  amazon: [
    "amazon.com", "amazon.in", "amazon.co.uk", "amazon.de", "amazon.ca",
    "amazon.fr", "amazon.es", "amazon.it", "amazon.co.jp", "amazon.com.au",
    "aws.amazon.com"
  ],
  paypal: ["paypal.com"],
  netflix: ["netflix.com"],
  bankofamerica: ["bankofamerica.com", "bofa.com"],
  chase: ["chase.com"],
  wellsfargo: ["wellsfargo.com"],
  stripe: ["stripe.com"],
  github: ["github.com"],
  linkedin: ["linkedin.com"],
  usps: ["usps.com", "usps.gov"],
  fedex: ["fedex.com"],
  ups: ["ups.com"],
  dhl: ["dhl.com", "dhl.de"],
  singtel: ["singtel.com", "singtel.com.sg"],
  singpost: ["singpost.com", "singpost.gov.sg", "singpost.com.sg"],
  singaporepost: ["singpost.com", "singpost.gov.sg", "singpost.com.sg"],
  grab: ["grab.com", "grab.co.id", "grab.sg"],
  metamask: ["metamask.io", "consensys.io"],
  iras: ["iras.gov.sg"],
  visa: ["visa.com", "visa.co"],
  mastercard: ["mastercard.com", "mastercard.co"],
  shopify: ["shopify.com", "shopifyemail.com", "myshopify.com"],
  spotify: ["spotify.com"]
};

/**
 * Check if a domain belongs to a protected institutional or financial brand.
 */
function isProtectedBrandDomain(domain) {
  if (!domain) return false;
  const d = domain.toLowerCase().replace(/^www\./, "");
  if (ALL_OFFICIAL_DOMAINS.has(d)) return true;
  for (const brand of MATCHABLE_BRANDS) {
    const officialDomains = OFFICIAL_BRAND_DOMAINS[brand] || [`${brand}.com`];
    if (officialDomains.some(official => d === official || d.endsWith(`.${official}`))) {
      return true;
    }
  }
  return false;
}

/**
 * Every domain that is the official home of some brand in the list above.
 *
 * Without this, a real domain can be Levenshtein-matched against a *different*
 * brand and reported as a typosquat. Adding "grab" to the brand list made
 * `grab.com` look 2 edits from "iras" - a genuine false positive on a real
 * company. A domain that is officially some brand's own cannot be a typosquat
 * of anyone, so it is exempt from every spoofing check below.
 */
const ALL_OFFICIAL_DOMAINS = new Set(Object.values(OFFICIAL_BRAND_DOMAINS).flat());

/**
 * Free webmail and consumer mail providers.
 *
 * These MUST NOT confer "official sender" status. Several of them appear in
 * OFFICIAL_BRAND_DOMAINS - gmail.com legitimately belongs to Google - and the
 * brand loop sets `isLegitimateOfficialSender` when a domain matches any
 * brand's official list. The consequence was severe and silent: every scam sent
 * from a Gmail address was treated as legitimate, its score was capped at 25,
 * and the severe-domain disqualifiers were skipped entirely.
 *
 * No legitimate brand sends its transactional mail from a consumer mailbox, so
 * exempting these costs nothing and closes a large false-negative channel.
 */
const FREE_MAIL_DOMAINS = new Set([
  "gmail.com", "googlemail.com", "outlook.com", "hotmail.com", "hotmail.co.uk",
  "live.com", "msn.com", "yahoo.com", "yahoo.co.uk", "yahoo.co.in", "ymail.com",
  "aol.com", "icloud.com", "me.com", "mac.com", "protonmail.com", "proton.me",
  "gmx.com", "gmx.de", "mail.com", "zoho.com", "yandex.com", "yandex.ru",
  "qq.com", "163.com", "126.com", "naver.com", "hanmail.net", "rediffmail.com"
]);

/** A domain that can never make a message look official. */
function isFreeMailDomain(domain) {
  if (!domain) return false;
  const d = domain.toLowerCase().replace(/^www\./, "");
  if (FREE_MAIL_DOMAINS.has(d)) return true;
  // Any subdomain of a consumer provider counts too.
  for (const free of FREE_MAIL_DOMAINS) {
    if (d.endsWith("." + free)) return true;
  }
  return false;
}

/**
 * Signature-footer markers.
 *
 * A genuine corporate signature names a legal entity and usually carries a
 * copyright line. Pairing one of these with a known brand name, then checking
 * that the sending domain is NOT an official domain for that brand, is a very
 * high-precision impersonation test: legitimate brand mail comes from the
 * brand's own domain.
 */
const SIGNATURE_FOOTER_PATTERNS = [
  /©\s*\d{4}\s*(?:\(c\)\s*)?(?:by\s+)?/i,
  /copyright\s+\d{4}\s*(?:by\s+)?/i,
  /all\s+rights\s+reserved/i,
  /[\w\s.&]{2,40}\b(?:B\.V\.|Pte\.?\s*Ltd\.?|Ltd\.?|Inc\.?|LLC\.?|GmbH|S\.A\.|A\.G\.)/i,
  /\bteam\s+[A-Z][\w]{2,}\b/,
  /\bthis\s+email\s+and\s+accompanying\b/i
];

/**
 * Established, legitimate domains that are NOT in OFFICIAL_BRAND_DOMAINS but are
 * easily mistaken for a brand by edit distance. "shopify.com" sits 2 edits from
 * "spotify.com", so without this it was flagged as a typosquat - a false
 * positive that would have trained users to ignore the banner.
 * Being a real company means the domain is exempt from spoofing checks.
 */
const LEGITIMATE_DOMAINS = new Set([
  "shopify.com", "wix.com", "squarespace.com", "weebly.com", "bigcartel.com",
  "stripe.com", "square.com", "paypal.me", "wise.com", "revolut.com",
  "slack.com", "zoom.us", "webex.com", "teams.microsoft.com",
  "box.com", "dropbox.com", "icloud.com", "onedrive.com", "drive.google.com",
  "mailchimp.com", "hubspot.com", "sendgrid.com", "mailgun.com", "postmark.com",
  "twilio.com", "intercom.com", "zendesk.com", "freshdesk.com",
  "asana.com", "trello.com", "monday.com", "atlassian.com", "confluence.com",
  "figma.com", "canva.com", "adobe.com", "salesforce.com", "oracle.com",
  "ibm.com", "intel.com", "cisco.com", "dell.com", "hp.com", "logitech.com",
  "samsung.com", "sony.com", "nike.com", "adidas.com", "walmart.com",
  "target.com", "bestbuy.com", "costco.com", "etsy.com", "ebay.com",
  "soundcloud.com", "bandcamp.com", "discogs.com", "medium.com", "substack.com",
  "notion.so", "airtable.com", "linear.app", "vercel.app", "netlify.app",
  "gitlab.com", "codeforces.com", "mamaearth.in", "shiprocket.in", "fastag.ihmcl.com", "bookmyshow.com"
]);

/**
 * Homoglyph / Character-Substitution Normalizer
 */
function normalizeForBrandCheck(str) {
  if (!str) return "";
  return str
    .toLowerCase()
    .replace(/1/g, "i")
    .replace(/0/g, "o")
    .replace(/rn/g, "m")
    .replace(/vv/g, "w")
    .replace(/5/g, "s")
    .replace(/[@4]/g, "a")
    .replace(/3/g, "e")
    .replace(/\$/g, "s");
}

/**
 * Second homoglyph reading. The spec's substitution table lists `1` as standing
 * for "i" OR "l", and single-digit swaps are the most common trick there is.
 * "paypa1" only resolves to "paypal" under this reading - under the `1`->`i`
 * pass it becomes "paypai", which matches nothing.
 */
function normalizeAltForBrandCheck(str) {
  if (!str) return "";
  return str
    .toLowerCase()
    .replace(/1/g, "l")
    .replace(/0/g, "o")
    .replace(/rn/g, "m")
    .replace(/vv/g, "w")
    .replace(/5/g, "s")
    .replace(/[@4]/g, "a")
    .replace(/3/g, "e")
    .replace(/\$/g, "s");
}

/**
 * Standard Levenshtein Distance Calculator
 */
function levenshteinDistance(a, b) {
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  const matrix = Array.from({ length: a.length + 1 }, () => []);

  for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
  for (let j = 0; j <= b.length; j++) matrix[0][j] = j;

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  return matrix[a.length][b.length];
}

const URGENCY_PATTERNS = [
  { regex: /expire(s|d|ing)?\s+today/i, reason: "Urgency trigger ('expires today')" },
  { regex: /action\s+required/i, reason: "Urgency trigger ('action required')" },
  { regex: /within\s+(?:the\s+next\s+)?\d+\s*(?:hours?|mins?|minutes?|days?)/i, reason: "Psychological time limit constraint" },
  { regex: /account\s+(suspended|locked|terminated|restricted|disabled|expired)/i, reason: "Fear trigger: account suspension/lock warning" },
  { regex: /unusual\s+(activity|login|transaction|charge|access)/i, reason: "Fear trigger: unusual security activity alarm" },
  { regex: /click\s+here\s+to\s+(verify|update|confirm|login|restore)/i, reason: "Urgent action demand" },
  { regex: /will\s+be\s+(suspended|locked|disabled|terminated|deactivated|closed|expired)/i, reason: "Threat of account loss ('will be suspended')" },
  { regex: /your\s+(account|payment|parcel|package|order)\s+(has\s+been|was|is)\s+(suspended|locked|cancelled|held|failed)/i, reason: "Claimed account/package hold" },
  { regex: /final\s+notice|last\s+warning/i, reason: "Escalating panic phrase" },
  { regex: /failure\s+to\s+renew|photos\s+(?:and\s+videos\s+)?will\s+be\s+(?:deleted|removed)|data\s+is\s+scheduled\s+for\s+deletion|permanently\s+(?:purged|removed)/i, reason: "Threatened data deletion / storage loss urgency" }
];

const CREDENTIAL_PATTERNS = [
  { regex: /verify\s+your\s+(credentials|account|password|identity|access)/i, reason: "Credential verification demand" },
  { regex: /confirm\s+your\s+(identity|password|account|credentials|details|information)/i, reason: "Identity confirmation demand" },
  { regex: /(?:enter|confirm|verify|provide)\s+(?:your\s+)?(?:debit\s+card\s+|credit\s+card\s+|account\s+)?(password|pin|ssn|passcode|code)/i, reason: "Sensitive credential harvesting request" },
  { regex: /provide\s+(your\s+)?(otp|one-time\s+password|verification\s+code)/i, reason: "Authentication OTP theft attempt" },
  { regex: /(login|auth|signin|password-reset)\s*link/i, reason: "Login credential capture link" }
];

const TRANSACTIONAL_SAFEGUARD_PATTERNS = [
  // 1. CI/CD & Developer Workflow
  { regex: /\b(?:workflow|run|build|pipeline|job|check)\s+(?:failed|succeeded|passed|completed|errored)\b/i, reason: "CI/CD developer workflow status notification" },
  { regex: /\bmerge\s+request\s+!(?:\d+)\s+was\s+merged\b|\bpull\s+request\s+#(?:\d+)\s+(?:merged|closed|opened)\b/i, reason: "Code collaboration version control activity" },
  { regex: /\bdependabot\s+alert|\b(?:npm|docker|pypi)\s+package\s+(?:published|build)\b/i, reason: "Software dependency/package registry notification" },
  { regex: /\bmonitor\s+\[.*?\]\s+recovered|\bservice\s+latency\s+is\s+back\b/i, reason: "DevOps monitoring recovery notification" },

  // 2. Order Fulfillment, Logistics & Deliveries
  { regex: /\border\s+#?[\w-]+\s+(?:your\s+order\s+)?has\s+been\s+delivered\b/i, reason: "E-commerce verified order delivery confirmation" },
  { regex: /\b(?:out\s+for\s+delivery|delivered\s+by|handed\s+directly\s+to\s+resident)\b/i, reason: "Active parcel courier delivery notice" },
  { regex: /\btracking\s+(?:awb|number|id)[:\s#]*[a-z0-9]+/i, reason: "Courier parcel tracking AWB reference" },
  { regex: /\b(?:ride|trip|order)\s+(?:receipt|invoice)\b|\bdelivered\s+in\s+\d+\s+minutes\b/i, reason: "Transportation or on-demand delivery receipt" },
  { regex: /\b(?:view\s+(?:your\s+)?order|thank\s+you\s+for\s+your\s+order|order\s+confirmation|order\s+#\s*[\w-]+)\b/i, reason: "E-commerce order confirmation and receipt" },
  { regex: /@(?:[\w-]+\.)?shopifyemail\.com\b/i, reason: "Verified Shopify merchant transactional notification" },
  { regex: /\breturn\s+item\s+has\s+been\s+inspected\s+and\s+picked\s+up\b|\brefund\s+initiated\b/i, reason: "E-commerce product return pickup status" },

  // 3. Official Banking, Regulatory, Compliance & Salary
  { regex: /\bcollateral\s+at\s+client\s+level\b|\bcompliance\s+with\s+sebi\s+regulations\b/i, reason: "Regulatory securities compliance disclosure" },
  { regex: /\bsalary\s+credited\s+to\s+your\s+account\b|\bcredited\s+with\s+inr\s+[\d,.]+\s+via\s+neft\b/i, reason: "Direct payroll salary credit confirmation" },
  { regex: /\bmonthly\s+e-statement\s+for\s+your\s+(?:credit\s+card|account)\b/i, reason: "Official monthly bank/card statement" },
  { regex: /\bterms\s+and\s+policies\b|\bdeveloper\s+distribution\s+agreement\b/i, reason: "Platform developer terms of service update" },

  // 4. Operational Ticketing, Travel & Appointments
  { regex: /\belectronic\s+reservation\s+slip\s+\(ers\)\s+pnr\b|\bcoach\s+[a-z0-9]+,\s*berth\s+\d+\b/i, reason: "Official railway reservation confirmation" },
  { regex: /\bboarding\s+pass\b|\bgate\s+closes\s+\d+\s+minutes\s+prior\b/i, reason: "Airline electronic boarding pass" },
  { regex: /\bappointment\s+(?:is\s+)?confirmed\s+for\b|\bdr\.\s+[a-z]+\s+\(cardiology|pediatrics|general\)\b/i, reason: "Medical healthcare appointment confirmation" },
  { regex: /\bround\s+\d+\s+will\s+take\s+place\s+tomorrow\s+at\s+\d+:\d+\s+utc\b/i, reason: "Scheduled competitive programming round announcement" },
  { regex: /\bworkspace\s+invited\b|\bis\s+inviting\s+you\s+to\s+a\s+scheduled\s+zoom\s+meeting\b/i, reason: "Direct team collaboration workspace or meeting invitation" },
  { regex: /\bfall\s+\d{4}\s+final\s+examination\s+schedule\b|\bcapstone\s+submission\s+for\b/i, reason: "Academic university administration notice" }
];

const PROMOTIONAL_CLUTTER_PATTERNS = [
  { regex: /unsubscribe/i, reason: "Post-registration promotional newsletter link", highIntent: false },
  { regex: /noreply@[a-z0-9.-]+\.(news|club|top|xyz|info|promo|tech)/i, reason: "Automated post-registration marketing sender", highIntent: false },
  { regex: /apply\s+(today|now)|register\s+(now|today)|join\s+[a-z0-9]+\s+(today|now)/i, reason: "Marketing call to action", highIntent: false },
  { regex: /exclusive\s+invite|limited\s+seats|explore\s+how|% off|discount/i, reason: "Promotional marketing offer", highIntent: false },

  // EdTech & Career Marketing Blasts (Parikh Jain, Interview Coaching, Placements)
  { regex: /\b\d+[\d,]*\+?\s*(?:students|learners|graduates|candidates|professionals)\s*(?:hired|placed|enrolled|trained|cracked)\b/i, reason: "EdTech placement record brag & student career marketing", highIntent: true },
  { regex: /\b\d+[\d,]*\+?\s*(?:companies|partner\s+companies|hiring\s+partners)\b/i, reason: "EdTech corporate hiring network marketing", highIntent: true },
  { regex: /\b(?:crack|master|ace|prepare\s+for)\s+(?:[a-z\s]{0,25})interviews?\b/i, reason: "Career coaching & tech interview prep sales pitch", highIntent: true },
  { regex: /\b(?:free\s+)?(?:masterclass|bootcamp|live\s+workshop|cohort|average\s+(?:ctc|package)|placement\s+(?:assistance|guarantee))\b/i, reason: "EdTech promotional course/bootcamp pitch", highIntent: true },

  // Retail Merchandising, Styling & Lifestyle Catalog Marketing (Rinske Fris, Store sales)
  { regex: /\b(?:strategy\s+for\s+(?:a\s+)?wardrobe|wardrobe\s+strategy|be\s+the\s+annoying\s+customer)\b/i, reason: "Lifestyle styling & wardrobe merchandise marketing pitch", highIntent: true },
  { regex: /\b(?:explore|browse|shop)\s+(?:our\s+)?(?:collection|new\s+arrivals|catalog|store|latest\s+drop)\b/i, reason: "Retail catalog merchandising offer", highIntent: true },
  { regex: /\b(?:flat|upto|up\s+to|\d{1,2}%)\s*(?:off|discount|cashback|sale)\b/i, reason: "Retail promotional discount offer", highIntent: true },
  { regex: /\buse\s+(?:coupon|code|promo\s+code)\s+[A-Z0-9]+\b/i, reason: "Promotional coupon code offer", highIntent: true },
  { regex: /\b(?:limited\s+time\s+offer|exclusive\s+deal|weekend\s+sale|clearance\s+sale)\b/i, reason: "Promotional clearance/deal offer", highIntent: true },

  // Commercial Content Newsletters & Financial Digests (Vested Shorts, Morning Brew, TLDR Tech)
  { regex: /\b(?:daily|weekly|monthly)\s+(?:global\s+)?market\s+(?:commentary|overview|recap|insights)\b/i, reason: "Commercial market commentary digest", highIntent: true },
  { regex: /\bvested\s+shorts\b|\bshorts\s+daily\b/i, reason: "Commercial financial market shorts newsletter", highIntent: true },
  { regex: /\b(?:tldr\s+tech|byte-sized\s+daily\s+news|morning\s+brew|top\s+stories\s+shaping\s+business)\b/i, reason: "Commercial curated tech/business newsletter", highIntent: true },
  { regex: /\bstories\s+for\s+[a-z]+:.*?recommended\s+reads\b/is, reason: "Curated content recommendation digest", highIntent: true },
  { regex: /\b(?:take\s+a\s+look\s+at\s+standard\s+provident\s+fund|here\s+is\s+how\s+much\s+of\s+it\s+goes\s+into\s+pf)\b/i, reason: "Career newsletter financial advisory blast", highIntent: true },

  // Cold-blast opt-out mechanics
  { regex: /put\s+(?:the\s+word\s+)?["“']?[\s-]*(?:remove|remove-me|unsubscribe|stop|opt[\s-]?out)["”']?\s+(?:on|in|to)\s+the\s+subject/i, reason: "Opt-out by replying with a keyword instead of an unsubscribe link", highIntent: true },
  { regex: /reply\s+with\s+["“'][^"”]{1,40}["”]\s+on\s+the\s+(?:email\s+)?subject/i, reason: "Registration triggered by a keyword reply, not a form", highIntent: true },
  { regex: /if\s+you\s+(?:prefer|wish)\s+not\s+to\s+receive\s+(?:any\s+)?(?:further|more|future)\s+emails?/i, reason: "Bulk sender states its own opt-out terms in the body", highIntent: true },
  { regex: /feel\s+free\s+to\s+request\s+(?:a\s+|our\s+)?brochures?\b/i, reason: "Cold brochure request with no self-service path", highIntent: true }
];

/**
 * Mailbox-provider quarantine notices.
 *
 * These are NOT properties of the message: they are the verdict Gmail already
 * reached and is displaying to the user. The extension copies that banner text
 * into the analyzed payload (see extension/content-script.js), and until this
 * existed no rule matched it, so the single most decisive piece of evidence in
 * the request was silently discarded.
 *
 * The concrete case that motivated this: a newsletter from an official brand
 * domain (quora.com) that the user had blocked. Gmail quarantined it and said
 * so on screen, but "You have blocked <address>" matched nothing, the official
 * domain cap clamped the score to 25, and the banner reported "consistent with
 * legitimate mail" next to a red RISK badge in the same window.
 *
 * Deliberately narrow, and it never claims the message is a threat - being
 * blocked is a user preference, not proof of phishing - so it floors the score
 * into the promo/unwanted band rather than forcing high_risk. Only the explicit
 * "suspected phishing" / "not opened by anyone" wording escalates, because
 * those describe Google's own classifier disagreeing with the sender.
 */
const QUARANTINE_NOTICE_PATTERNS = [
  {
    regex: /you have blocked\s+[^\s@]+@[^\s<>()]+/i,
    reason: "Sender is on the recipient's blocked-senders list, so Gmail routed this to Spam",
    escalate: false
  },
  {
    regex: /why is this message in spam\?/i,
    reason: "Gmail quarantined this message and displayed its spam explanation",
    escalate: false
  },
  {
    regex: /this message (?:was )?(?:may look )?like spam|looks like (?:unwanted|bulk)/i,
    reason: "Mailbox provider classified this message as unwanted bulk mail",
    escalate: false
  },
  {
    regex: /suspected (?:phishing|spam)|not opened by (?:any|everyone)|recipients haven't opened/i,
    reason: "Mailbox provider flagged this message as suspected phishing",
    escalate: true
  }
];

const SUSPICIOUS_DOMAINS = [
  { regex: /[a-z0-9-]+\.(xyz|top|tk|club|work|gq|cf|ml|monster|rest|hair|cfd)/i, reason: "High-risk top-level domain (TLD)" },
  // Cheap, heavily-abused TLDs. Added after an external corpus showed the
  // original six-digit list missed every real-world sample. These are not
  // malicious on their own, but a link to one in unsolicited mail is a strong
  // signal on its own.
  { regex: /https?:\/\/[\w.-]*\.(page|icu|buzz|cam|lol|monster|online|site|space|link|click|fun|trade|rest|cfd|fit|quest|cyou|sbs|icu)\b/i, reason: "Link to a heavily-abused cheap top-level domain" },
  { regex: /http:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i, reason: "Raw IP address URL instead of domain" },
  {
    // URL shorteners hide the real destination, a staple of smishing /
    // delivery-fraud lures. Detected generically so new services are covered too.
    regex: /https?:\/\/(?:www\.)?(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl|ow\.ly|is\.gd|buff\.ly|rebrand\.ly|cutt\.ly|shorturl\.at|rb\.gy|tiny\.cc|t\.ly|lnkd\.in|db\.tt|qr\.ae|v\.gd|s\.id|lnk\.to)\b|\b(?:bit\.ly|tinyurl\.com|rebrand\.ly|cutt\.ly|shorturl\.at|tiny\.cc|lnk\.to)\//i,
    reason: "URL shortener conceals the true destination domain"
  },
  // Firebase Hosting (and similar) is a free, anonymous static host routinely
  // used to serve phishing pages impersonating a named brand. On its own it is
  // not malicious - plenty of legitimate hobby projects live there - so it is
  // weighted lightly and only becomes strong when combined with a brand
  // impersonation or an action request.
  { regex: /https?:\/\/[\w.-]*\.firebaseapp\.com/i, reason: "Free anonymous hosting used to serve a lookalike page" },
  { regex: /https?:\/\/[\w.-]*\.(pages\.dev|web\.app|netlify\.app|vercel\.app)\b/i, reason: "Generic app-hosting domain behind a branded claim" }
];

/**
 * Social-engineering families the original rule set did not cover.
 *
 * These were added after running a real, externally-sourced corpus of 20
 * confirmed scam emails through the engine, which caught 0 of them. The engine
 * was built almost entirely around one family - credential phishing behind a
 * typosquatted brand domain - while the largest real-world category is
 * advance-fee and brand-impersonation fraud, where the payload is a request
 * for money, identity documents, or a phone call rather than a password.
 *
 * Weights are deliberately modest. The lift comes from the COMBINATION rules
 * further down: an unsolicited money claim on its own is a marketing email,
 * and a request for your ID on its own is unusual but not proof. Money bait
 * plus a contact-or-payment instruction is essentially conclusive.
 */
const ADVANCE_FEE_PATTERNS = [
  { regex: /you\s+have\s+been\s+selected\s+to\s+receive/i, reason: "Unsolicited 'you have been selected' prize claim" },
  { regex: /lucky\s+(winner|beneficiar)/i, reason: "Advance-fee lottery: 'lucky winner' framing" },
  { regex: /your\s+email\s+address\s+was\s+found\s+in\s+the\s+list/i, reason: "Advance-fee lottery: claimed address list" },
  { regex: /\$\s?[\d,.]+\s*(million|m)\s*(usd|sgd|eur|gbp)?/i, reason: "Large unsolicited monetary claim" },
  { regex: /western\s+union|wire\s+transfer|money\s+gram|moneygram/i, reason: "Remittance channel named in an unsolicited offer" },
  { regex: /activat\w*\s+fee|account\s+activation\s+fee/i, reason: "Advance-fee pretext: 'activation fee'" },
  { regex: /charitable\s+donation\s+of\s+\$/i, reason: "Unsolicited charitable donation claim" },
  { regex: /compensa\w+\s+(fund|amount)\b/i, reason: "Unsolicited compensation fund claim" },
  { regex: /get\s+\d{1,3}\s*%\s+for\s+your\s+(cooperation|partnership)/i, reason: "Unsolicited revenue-share 'partnership' offer" },
  { regex: /lottery\s+winnings?|grant\s+sum\s+of|grant\s+of\s+[€$£]|compensation\s+payment|irrevocable\s+compensation/i, reason: "Unsolicited grant, lottery or compensation payout claim" },
  { regex: /(?:respond|reply)\s+(?:back\s+)?to\s+this\s+email\s+(?:to\s+(?:claim|receive|collect|release|proceed)|with\s+your\s+(?:full\s+name|banking|account|details|id|information|passport))/i, reason: "Claim released only by emailing back a stranger" },
  { regex: /international\s+certified\s+bank\s+draft|finance\s+house|contact\s+agent\b/i, reason: "Named 'finance house' acting as a payout intermediary" },
  { regex: /(?:currency\s+of\s+)?\d[\d,.]*\s*(?:million|m)\b[^.]{0,40}(?:usd|sgd|eur|gbp|rm)|(?:usd|sgd|eur|gbp|rm)\s?\d[\d,.]*\s*(?:million|m)\b/i, reason: "Multi-million advance-fee amount" },
  { regex: /grant\s+(support\s+)?fund|disbursement\s+reference/i, reason: "Unsolicited grant or disbursement payout claim" }
];

const REFUND_BAIT_PATTERNS = [
  { regex: /\brefund\s+(bill|amount|of|has\s+been)\b/i, reason: "Unsolicited refund claim presented as an action item" },
  { regex: /overpayment|payment\s+was\s+made\s+twice|invoice\s+was\s+paid\s+twice/i, reason: "Fake overpayment / double-charge refund pretext" },
  { regex: /submit\s+your\s+refund|request\s+a\s+refund|claim\s+your\s+refund/i, reason: "Refund claim routed through an email link" },
  { regex: /will\s+be\s+credited\s+within\s+\d+/i, reason: "Promised credit used to legitimise a fake charge" },
  { regex: /complete\s+within\s+\d+\s+days?\s+for\s+prompt\s+processing/i, reason: "Short deadline attached to a refund pretext" }
];

const DELIVERY_FEE_PATTERNS = [
  { regex: /non-?payment\s+of\s+[\d.,]+\s*(sgd|usd|eur|gbp|\$)?/i, reason: "Parcel-release fee demanded for a held shipment" },
  { regex: /pay\s+the\s+new\s+shipping\s+cost|outstanding\s+customs\s+(fee|charge)/i, reason: "Shipping-fee pretext to release a parcel" },
  { regex: /delivery\s+failed\s+on|incorrect\s+address.*(?:pay|shipping)/i, reason: "Failed-delivery pretext paired with a payment link" },
  { regex: /could\s+not\s+be\s+delivered\s+due\s+to\s+an\s+invalid\s+address\s+fee/i, reason: "Small-fee delivery scam (classic smishing)" },
  { regex: /on\s+hold\s+in\s+our\s+post|still\s+on\s+hold/i, reason: "Shipment held pending payment" },
  { regex: /unable\s+to\s+deliver|were\s+unable\s+to\s+deliver|parcel\s+could\s+not\s+be\s+delivered/i, reason: "Failed-delivery notice used to drive a click" },
  { regex: /confirm\s+the\s+next\s+steps\s+to\s+reschedule/i, reason: "Delivery reschedule routed through an email link" },
  { regex: /confirm\s+the\s+payment\s*\([0-9,.]+\s*(euros?|eur|sgd|usd|\$)?\)|parcel\s+is\s+waiting\s+for\s+delivery/i, reason: "Payment confirmation demanded to release parcel" }
];

const FAKE_SUBSCRIPTION_PATTERNS = [
  { regex: /storage\s+is\s+full|cloud\s+storage\s+(alert|reminder)/i, reason: "Fake cloud-storage exhaustion scare" },
  { regex: /upgrade\s+(your\s+)?storage|not\s+backing\s+up/i, reason: "Storage upgrade upsell via unsolicited mail" },
  { regex: /subscription\s+renewal\s+has\s+been\s+processed/i, reason: "Auto-renewal notice for a subscription the user may not hold" },
  { regex: /your\s+subscription\s+(ends|is\s+about\s+to\s+expire)/i, reason: "Subscription-expiry renewal lure" },
  { regex: /to\s+cancel\s+auto-?renewal,?\s*contact/i, reason: "Cancellation handled by phone/email rather than an account page" },
  { regex: /rewards?\s+will\s+expire|rewards?\s+expire\s+in\s+\d+|your\s+rewards?\b/i, reason: "Unsolicited 'your rewards expire' bait" },
  { regex: /claim\s+your\s+reward|get\s+\d+\s*(?:sgd|usd|eur|gbp|rm)\s+now/i, reason: "Reward claim pushed from unsolicited mail" },
  { regex: /membership\s+renewal|bill\s+receipt\s*[-:]\s*ord\d+/i, reason: "Fake membership renewal record" },
  { regex: /cashback\s+will\s+expire|claim\s+[\w$]+\s*cashback/i, reason: "Unsolicited cashback expiry lure" },
  { regex: /storage\s+(?:has\s+reached|reached)\s+critical\s+limit|storage\s+sync\s+(?:has\s+been\s+)?paused|storage\s+limit\s+(?:exceeded|reached)|cloud\s+files\s+will\s+be\s+removed|without\s+cloud\s+space|cloud\s+has\s+been\s+disabled/i, reason: "Fake cloud storage service disruption / deletion threat" }
];

const FAKE_SECURITY_PATTERNS = [
  { regex: /2fa\s+(will\s+be\s+|is\s+now\s+)?mandatory|mandatory\s+for\s+all\s+\w+\s+accounts/i, reason: "Mandatory 2FA enforcement notice" },
  { regex: /enable\s+2fa\s+now|2fa\s+will\s+be\s+enabled/i, reason: "2FA enrolment pushed from an email link" },
  { regex: /protect\s+your\s+wallet|keeping\s+your\s+digital\s+assets\s+safe/i, reason: "Wallet-protection pretext" },
  { regex: /we\s+tried\s+to\s+charge\s+your\s+account\s+but\s+the\s+transaction\s+was\s+declined/i, reason: "Declined-payment bait" },
  { regex: /(?:new|unread)\s+message\s+(?:waiting\s+for\s+you|on\s+your\s+dashboard)/i, reason: "Fake dashboard unread message lure" },
  { regex: /scan\s+(?:the\s+)?(?:embedded\s+)?qr\s*code|qr\s*code\s+required\s+for\s+(?:multi-factor|mfa|2fa|authenticator|setup)/i, reason: "Quishing / QR code authentication trap" },
  { regex: /update\s+your\s+authenticator|authenticator\s+setup|multi-factor\s+setup|mfa\s+setup/i, reason: "Authenticator/MFA configuration lure" },
  { regex: /cloud\s+antivirus\s+expired|threat\s+to\s+your\s+device|compromise\s+your\s+sim\s+card|renew\s+your\s+shield|unprotected\s+against\s+cyber\s+attacks|subscription\s+(?:termination\s+notice|will\s+be\s+closed|has\s+closed)/i, reason: "Fake security threat or subscription termination alert" }
];

const INVESTMENT_PATTERNS = [
  { regex: /\$\s?[A-Z]{2,6}\s+token|airdrop/i, reason: "Token/airdrop offer" },
  { regex: /launch\w*\s+[\s\S]{0,40}\s+own\s+digital\s+currency/i, reason: "Fabricated token launch attributed to an established brand" },
  { regex: /approved\s+and\s+disbursed\s+within\s+\d+\s+hours?/i, reason: "Instant-approval loan / advance-fee pitch" },
  { regex: /loan\s+solutions|private\s+loan\s+investment/i, reason: "Unsolicited loan/investment solicitation" },
  { regex: /investment\s+opportunit|extraordinary\s+solution/i, reason: "Vague investment promise with no verifiable instrument" }
];

const HEALTH_CLAIM_PATTERNS = [
  { regex: /self-?healing\s+protocol|vision\s+restoration\s+protocol/i, reason: "Unverifiable medical 'protocol' claim" },
  { regex: /from\s+nearly\s+blind\s+to\s+perfect\s+20\/20|clinical\s+trials?,?\s*[\d,]+\+?\s*patients/i, reason: "Implausible medical outcome statistic" },
  { regex: /before\s+the\s+video\s+is\s+taken\s+down|watch\s+the\s+(?:free\s+|unedited\s+|full\s+|banned\s+|silhouette\s+)?(?:presentation|video|seminar|report)/i, reason: "Artificial urgency to view a health claim/video" },
  { regex: /researchers\s+uncover|\bprotocol\s+is\s+changing\s+lives\b/i, reason: "Viral-marketing medical claim" },
  // Direct-response health-device advertorials. These quote no clinical trial
  // and cite no regulator, but assert a specific therapeutic outcome for a
  // consumer device - "reduce spinal pressure", "relieve sciatica" - and are
  // sold on a discount plus a money-back trial. Added because this shape
  // matched no other family and was consequently classified as bulk marketing.
  { regex: /reduce\s+spinal\s+pressure|support\s+disc\s+rehydration|create\s+space\s+between\s+vertebrae/i, reason: "Consumer device claims a specific therapeutic outcome for a medical condition" },
  { regex: /for\s+people\s+dealing\s+with\s+(?:recurring\s+)?(?:back\s+(?:pain|discomfort)|sciatica|joint\s+pain)/i, reason: "Targets a named medical complaint with an at-home product" },
  { regex: /(?:save|discount)\s+\d{1,3}%\s+on\b[\s\S]{0,80}money-?back\s+trial|money-?back\s+trial[\s\S]{0,80}(?:save|discount)\s+\d{1,3}%/i, reason: "Deep discount plus money-back trial, the standard health-device advertorial close" },
  { regex: /insulin\s+vampire|parasit\w+\s+infection|causing\s+type\s+2\s+diabetes|ancient\s+.*ritual|flushes?\s+it\s+out\s+of\s+the\s+pancreas/i, reason: "Fabricated parasite or miracle cure claim for a chronic condition" },
  { regex: /vicks\s+vapo\s*rub|vapo\s*rub\s+trick|vick\s+trick|shrink\s+(?:your\s+|inflamed\s+|enlarged\s+)?prostate|waking\s+up\s+\d+(?:-\d+)?\s+times\s+a\s+night\s+to\s+pee/i, reason: "Unsubstantiated prostate shrink / miracle cure claim" },
  { regex: /steelpower|rock\s+hard\s+stamina|male\s+vitality|men['’]?s\s+health\s+(?:alert|intelligence)/i, reason: "Direct-response male vitality advertorial" },
  { regex: /tomato\s+skin\s+(?:morning\s+)?protocol|tomato\s+skin\s+trick|stop\s+taking\s+flomax|flowstrong|firehose\s+stream|prostate\s+swelling/i, reason: "Miracle food / alternative protocol claim replacing medical treatment" },
  { regex: /rekindle\s+your\s+spark|instant\s+readiness|no\s+last-minute\s+pills|natural\s+mix\s+works|erection\s+solution/i, reason: "Alternative male performance drink / natural mix advertorial" },
  { regex: /horsewood|increases?\s+your\s+penis|[\d.]+\s*inch\s+gains?|doctor\s+exposes\s+the\s+trick/i, reason: "Fabricated anatomical growth / miracle medical trick" },
  { regex: /silhouette\s+video|endopump|stiff\s+as\s+steel|stiffens?\s+your\s+johnson|chicken-choking|restores\s+the\s+natural\s+blood\s+flow|jackhammer\s+her/i, reason: "Sensationalist performance remedy / silhouette video claim" },
  { regex: /prostavive|dissolves?\s+prostate\s+clog|spring\s+water\s+juice|pee\s+(?:hard\s+against\s+the\s+bowl|like\s+a\s+water\s+cannon|like\s+a\s+river)/i, reason: "Unsubstantiated prostate juice / urinary miracle remedy claim" },
  { regex: /diabetic\s+parasite|glycolean|why\s+your\s+doctor\s+hasn['’]?t\s+told\s+you|pharmaceutical\s+industry\s+is\s+furious|get\s+this\s+segment\s+scrubbed/i, reason: "Conspiracy-based diabetes miracle cure / parasite claim" },
  { regex: /barbara\s+o['’]?neill|banned\s+(?:lecture|seminar|video)|leaked\s+(?:lecture|broadcast|seminar)|regenerates?\s+dead\s+nerves|calm\s+(?:the\s+)?burning\s+and\s+tingling|neuropathic\s+pain/i, reason: "Fabricated 'banned lecture' / unverified neuropathy cure claim" }
];

const PERSONAL_DATA_PATTERNS = [
  { regex: /copy\s+of\s+your\s+identification|have\s+your\s+id\s+ready|valid\s+id\s+(card|document)/i, reason: "Requests a copy of identity documents by email" },
  { regex: /your\s+full\s+names?\s*[:\n]/i, reason: "Blank-field form requesting a full legal name" },
  { regex: /cell\/telephone\s+numbers?|home\s+or\s+office\s+address/i, reason: "Blank-field form requesting phone and address" },
  { regex: /your\s+country\s*[:\n]/i, reason: "Blank-field form requesting country of residence" },
  { regex: /re-?confirming\s+your\s+complete\s+information|provide\s+(to\s+them\s+)?the\s+following\s+information/i, reason: "Generic bulk personal-information request" }
];

const CONTACT_STRANGER_PATTERNS = [
  { regex: /contact\s+(me|us|him|her|them|him\/her)\s+urgently|contact\s+\w+\s+urgently/i, reason: "Demands an urgent off-channel reply" },
  { regex: /i\s+want\s+to\s+reach\s+a\s+partnership|partnership\s+agreement/i, reason: "Unsolicited partnership proposal" },
  { regex: /please\s+contact\s+\S+@\S+|contact\s+\S+\s+for\s+more\s+information/i, reason: "Redirects to an unrelated third-party address" },
  { regex: /your\s+urgent\s+attention\s+is\s+needed|for\s+your\s+claim\s+and\s+more/i, reason: "Bare urgency demand with no legitimate context" }
];

/**
 * Inheritance and estate ("next of kin") fraud.
 *
 * A distinct and heavily-used family: the sender claims a mutual ancestor,
 * a deceased relative who shared the recipient's surname, or a dying stranger
 * who needs a trustworthy stranger to hold their estate. The ask is always
 * the same - reply with contact details so a "law firm" or "finance house"
 * can proceed. It appeared twice in an eleven-message real-world sample, and
 * neither message contained a brand name, a money figure, or an action
 * request, so nothing else in the engine could see it.
 */
const INHERITANCE_PATTERNS = [
  { regex: /shared\s+your\s+surname|relative\s+to\s+(you|our\s+family)/i, reason: "Inheritance fraud: claims a shared surname" },
  { regex: /no\s+known\s+heirs?\b|without\s+any\s+known\s+heirs?/i, reason: "Inheritance fraud: claims the deceased has no heirs" },
  { regex: /passed\s+away\s+(recently|abroad)?|recently\s+(passed\s+away|died)/i, reason: "Inheritance fraud: invokes a recent death" },
  { regex: /\bwidow\s+(with|of)\b|stage\s+\d\s+cancer|my\s+days\s+are\s+numbered/i, reason: "Inheritance fraud: sympathy pretext" },
  { regex: /utili[sz]e\s+the\s+proceeds\s+realized|from\s+my\s+estates?\b/i, reason: "Inheritance fraud: offers an estate's proceeds" },
  { regex: /entrust\s+the\s+money\s+in\s+your\s+care|give\s+me\s+your\s+word\s+never\s+to\s+betray/i, reason: "Inheritance fraud: asks for an oath of trust" },
  { regex: /legal\s+representative\s+of\s+the\s+late|law\s+chambers/i, reason: "Inheritance fraud: unverified legal representative" }
];

/**
 * Large monetary amounts written with a currency word or code rather than a
 * bare "$" sign.
 *
 * The advance-fee table's amount pattern requires a literal "$", which misses
 * "EUR 1.5m", "US $ 700,000.00" and "€2.7 million" - the majority of
 * international advance-fee lures. Matching the code or symbol as well as the
 * bare sign closed that gap.
 */
const LARGE_AMOUNT_SOURCE = "(?:[$€£]\\s?\\d[\\d,.]*\\s*(?:million|m\\b|k\\b)|(?:us\\s?[$€£]|eur|usd|sgd|gbp|rm|myr|idr|inr|pkr|zar)\\s?[$€£]?\\s?\\d[\\d,.]*\\s*(?:million|m\\b))";

/**
 * Every new family above, with its weight.
 *
 * Weights are low by design. A single "refund" mention is a legitimate tax
 * notice; a single "urgent" is common. What separates fraud from commerce is
 * co-occurrence, handled by the combination rules in evaluateRules.
 */
const SOCIAL_ENGINEERING_FAMILIES = [
  { name: "advance_fee", points: 20, patterns: ADVANCE_FEE_PATTERNS },
  { name: "refund_bait", points: 18, patterns: REFUND_BAIT_PATTERNS },
  { name: "delivery_fee", points: 20, patterns: DELIVERY_FEE_PATTERNS },
  { name: "fake_subscription", points: 18, patterns: FAKE_SUBSCRIPTION_PATTERNS },
  { name: "fake_security", points: 20, patterns: FAKE_SECURITY_PATTERNS },
  { name: "investment", points: 15, patterns: INVESTMENT_PATTERNS },
  { name: "health_claim", points: 20, patterns: HEALTH_CLAIM_PATTERNS },
  { name: "personal_data", points: 15, patterns: PERSONAL_DATA_PATTERNS, corroboration: false },
  { name: "contact_stranger", points: 15, patterns: CONTACT_STRANGER_PATTERNS },
  { name: "inheritance", points: 25, patterns: INHERITANCE_PATTERNS }
];

/**
 * Any six-figure-or-larger amount with a currency marker.
 *
 * Deliberately broad - a plain "$250,000.00" carries no "million" or "k"
 * suffix, and the earlier suffix-requiring pattern missed the majority of
 * international advance-fee lures. On its own this proves nothing: legitimate
 * invoices quote six-figure amounts all the time. It is only ever used as one
 * half of a combination.
 */
const SIX_FIGURE_AMOUNT_RE =
  /[$€£]\s?\d{2,3}(?:,\d{3})+(?:\.\d{2})?|\b\d{2,3}(?:,\d{3})+\s*(?:usd|eur|gbp|sgd|rm|dollars|euros)\b/i;

/** Large-amount matcher, shared by the money-bait helpers below. */
const LARGE_AMOUNT_RE = new RegExp(LARGE_AMOUNT_SOURCE, "i");

/** Senders whose domain is a free, anonymous or abused host. */
const ABUSED_HOSTING_RE =
  /(^|\.)(firebaseapp\.com|pages\.dev|web\.app|netlify\.app|vercel\.app|blogspot\.[a-z]+|weebly\.com|wixsite\.com|glitch\.me|repl\.co|codesandbox\.io|000webhostapp\.com|duckdns\.org|no-ip\.org|ngrok\.io|trycloudflare\.com)$/i;

/**
 * Pull the display name out of a From/Reply-To header.
 *
 * The display name is the single most useful impersonation signal available:
 * attackers routinely write "MetaMask" or "Singtel" in the human-readable name
 * and send from an unrelated throwaway domain. The existing homoglyph and
 * Levenshtein checks only ever look at the domain, so they cannot see this.
 */
function extractSenderDisplayNames(text) {
  const headerRegex = /^\s*(?:from|sender|reply-to|return-path)\s*:\s*(.*)$/gim;
  const found = new Set();
  let m;
  while ((m = headerRegex.exec(text)) !== null) {
    const raw = m[1].trim();
    const angled = raw.match(/^\s*(?:"([^"]*)"|([^<>]*?))\s*</);
    if (angled) {
      const name = (angled[1] || angled[2] || "").trim();
      if (name) found.add(name);
    }
  }
  return Array.from(found);
}


function extractDomains(text) {
  // Accepts 2-label domains (paypa1-security.com) as well as deeper ones
  // (login.m1crosoft-support.com). The previous pattern required a third
  // label, so plain "brand-typosquat.tld" domains were never inspected.
  const domainRegex = /(?:https?:\/\/)?\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b/gi;
  const emailDomainRegex = /@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gi;
  const domains = new Set();

  let match;
  while ((match = domainRegex.exec(text)) !== null) {
    const domain = match[0].replace(/^https?:\/\//i, "").split("/")[0].toLowerCase();
    domains.add(domain);
  }

  while ((match = emailDomainRegex.exec(text)) !== null) {
    domains.add(match[1].toLowerCase());
  }

  return Array.from(domains);
}

/** Registered domain = last two labels (good enough for .co.uk style TLDs). */
function registeredDomain(domain) {
  const parts = domain.toLowerCase().replace(/^www\./, "").split(".");
  return parts.slice(-2).join(".");
}

/** Domains that appear inside a From:/Reply-To header. */
function extractSenderDomains(text) {
  const headerRegex = /^\s*(?:from|sender|reply-to|return-path)\s*:\s*.*?@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gim;
  const found = new Set();
  let m;
  while ((m = headerRegex.exec(text)) !== null) {
    found.add(m[1].toLowerCase().replace(/^www\./, ""));
  }
  return Array.from(found);
}

/**
 * The From: domain alone, ignoring Reply-To.
 *
 * Kept separate from extractSenderDomains because the two being *different* is
 * itself a strong phishing signal: a message that appears to come from an
 * institution but whose replies are redirected to a free webmail or lookalike
 * domain exists to defeat reply-path filtering on the receiving side.
 */
function extractFromDomains(text) {
  const found = new Set();
  const re = /^\s*from\s*:\s*.*?@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gim;
  let m;
  while ((m = re.exec(text)) !== null) {
    found.add(m[1].toLowerCase().replace(/^www\./, ""));
  }
  return Array.from(found);
}

/** The Reply-To: domain alone. */
function extractReplyToDomains(text) {
  const found = new Set();
  const re = /^\s*(?:reply-to|return-path)\s*:\s*.*?@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gim;
  let m;
  while ((m = re.exec(text)) !== null) {
    found.add(m[1].toLowerCase().replace(/^www\./, ""));
  }
  return Array.from(found);
}

/**
 * Mixed-script homoglyph detection.
 *
 * A word that is almost entirely Latin but contains one or two Cyrillic or
 * Greek characters - a Cyrillic "о" inside "Yоurs", for example - is
 * invisible to a human reader and is used to defeat string-matching filters
 * and to spoof a bank name in a signature. Legitimate English business mail
 * essentially never mixes scripts mid-word, so this is high precision.
 *
 * Only characters from the Cyrillic and Greek blocks are considered, and only
 * when the surrounding text is otherwise Latin. Names written entirely in one
 * non-Latin script are ignored, since a Russian-language email is not an
 * attack.
 */
const CYRILLIC_OR_GREEK = /[\u0370-\u03FF\u0400-\u04FF]/g;

function findMixedScriptTokens(text) {
  const hits = [];
  // Words of letters, optionally containing internal punctuation.
  const tokenRe = /[A-Za-z\u0370-\u03FF\u0400-\u04FF][A-Za-z0-9\u0370-\u03FF\u0400-\u04FF'.-]*/g;
  let m;
  while ((m = tokenRe.exec(text)) !== null) {
    const token = m[0];
    CYRILLIC_OR_GREEK.lastIndex = 0;
    const nonLatin = token.match(CYRILLIC_OR_GREEK);
    if (!nonLatin) continue;
    const latinCount = (token.match(/[A-Za-z]/g) || []).length;
    // Require the token to be predominantly Latin, so a genuinely Cyrillic
    // word is not reported.
    if (latinCount < token.length * 0.5) continue;
    // A single stray non-Latin character inside an otherwise-Latin word is the
    // exact shape of a homoglyph attack; require at least one, but not all.
    hits.push({ token, nonLatin: nonLatin.slice(0, 3) });
    if (hits.length >= 5) break;
  }
  return hits;
}

/** Domains that appear as clickable link targets in the body. */
function extractLinkDomains(text) {
  const urlRegex = /https?:\/\/([a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+)/gi;
  const found = new Set();
  let m;
  while ((m = urlRegex.exec(text)) !== null) {
    found.add(m[1].toLowerCase().replace(/^www\./, ""));
  }
  return Array.from(found);
}

/**
 * Evaluates cryptographic and envelope authentication headers (SPF, DKIM, DMARC).
 */
function evaluateAuthentication(auth, senderDomain) {
  const flags = [];
  let score = 0;
  let isAuthDisqualified = false;

  if (!auth || typeof auth !== "object") {
    return { flags, score, isAuthDisqualified };
  }

  const fromDomain = (auth.fromDomain || senderDomain || "").toLowerCase().trim().replace(/^www\./, "");
  const signedBy = auth.signedBy ? auth.signedBy.toLowerCase().trim().replace(/^www\./, "") : null;
  const mailedBy = auth.mailedBy ? auth.mailedBy.toLowerCase().trim().replace(/^www\./, "") : null;
  const dmarc = auth.dmarc ? auth.dmarc.toLowerCase().trim() : null;
  const spf = auth.spf ? auth.spf.toLowerCase().trim() : null;
  const dkim = auth.dkim ? auth.dkim.toLowerCase().trim() : null;

  // Check A: Explicit Failures
  if (dmarc === "fail" || dkim === "fail" || spf === "fail") {
    flags.push({
      span: fromDomain || senderDomain || "Authentication Check",
      reason: "Cryptographic sender authentication failed (DMARC/DKIM/SPF violation).",
      type: "rule",
      rule: "AUTH_CRYPTO_FAIL"
    });
    score += 85;
    isAuthDisqualified = true;
  }

  // Known legitimate shared email service providers / relay infrastructure for SPF
  const SHARED_RELAYS = new Set([
    "amazonses.com", "sendgrid.net", "mailgun.org", "mailgun.net", "mandrillapp.com",
    "sparkpostmail.com", "mailchimpapp.net", "mcsv.net", "hubspotemail.net", "postmarkapp.com",
    "zendesk.com", "freshdesk.com", "salesforce.com", "exacttarget.com", "sailthru.com"
  ]);

  const isSharedRelay = (domain) => {
    if (!domain) return false;
    for (const relay of SHARED_RELAYS) {
      if (domain === relay || domain.endsWith("." + relay)) return true;
    }
    return false;
  };

  // Free webmail must never count as a brand sender here.
  //
  // gmail.com legitimately belongs to Google and icloud.com to Apple, so both
  // are in OFFICIAL_BRAND_DOMAINS and isProtectedBrandDomain() returns true for
  // them. Without this exclusion, every ordinary personal email sent from a
  // Gmail or Outlook address tripped AUTH_BRAND_UNAUTHENTICATED and scored ~41
  // "suspicious" for no reason at all - a friend emailing you from their own
  // Gmail account is the single most common case in an inbox.
  //
  // The identical exclusion already exists in the main evaluateRules() path
  // (and is documented on FREE_MAIL_DOMAINS), but this authentication path was
  // missed, so the same domain was simultaneously "official" here and
  // "not official" there.
  //
  // The reasoning is the same: no brand sends its own transactional mail from a
  // consumer mailbox, so there is no legitimate case to preserve. Real spoofing
  // is still caught by Checks B and C, which key on an actual signature being
  // present and MISALIGNED rather than absent.
  const isBrand = isProtectedBrandDomain(fromDomain) && !isFreeMailDomain(fromDomain);

  // Check B: DKIM Alignment Mismatch (The Smoking Gun)
  if (isBrand && signedBy) {
    const isDkimAligned = signedBy === fromDomain || signedBy.endsWith("." + fromDomain);
    if (!isDkimAligned) {
      flags.push({
        span: fromDomain,
        reason: `Sender claims '${fromDomain}', but message was digitally signed by unrelated domain '${signedBy}'.`,
        type: "rule",
        rule: "AUTH_DKIM_ALIGNMENT_MISMATCH"
      });
      score += 80;
      isAuthDisqualified = true;
    }
  }

  // Check C: SPF Envelope Mismatch
  if (isBrand && mailedBy) {
    const isSpfAligned = mailedBy === fromDomain || mailedBy.endsWith("." + fromDomain) || isSharedRelay(mailedBy);
    if (!isSpfAligned) {
      flags.push({
        span: fromDomain,
        reason: `Mail envelope ('${mailedBy}') does not align with sender domain '${fromDomain}'.`,
        type: "rule",
        rule: "AUTH_SPF_ENVELOPE_MISMATCH"
      });
      score += 50;
    }
  }

  // Check D: Unauthenticated High-Value Brand
  if (isBrand && !signedBy && !mailedBy && !dmarc && !dkim && !spf) {
    flags.push({
      span: fromDomain,
      reason: `Email claims to be from institutional brand '${fromDomain}' but carries no cryptographic signature.`,
      type: "rule",
      rule: "AUTH_BRAND_UNAUTHENTICATED"
    });
    score += 40;
  }

  return {
    flags,
    score,
    isAuthDisqualified
  };
}

function evaluateRules(text, channel = "email", auth = null, senderInfo = null) {
  const flags = [];
  let rawScore = 0;
  let isPromoClutter = false;
  let isBrandSender = false;

  if (!text || typeof text !== "string") {
    return { ruleScore: 0, flags: [], isPromoClutter: false, isAuthDisqualified: false, authSummary: null };
  }

  let explicitSenderAddress = "";
  let explicitSenderName = "";
  if (typeof senderInfo === "string") {
    explicitSenderAddress = senderInfo.trim();
  } else if (senderInfo && typeof senderInfo === "object") {
    explicitSenderAddress = (senderInfo.senderAddress || "").trim();
    explicitSenderName = (senderInfo.senderName || "").trim();
  }

  let explicitSenderDomain = "";
  if (explicitSenderAddress && explicitSenderAddress.includes("@")) {
    explicitSenderDomain = explicitSenderAddress.split("@").pop().toLowerCase().trim().replace(/^www\./, "");
  }

  const extractedDomains = extractDomains(text);
  if (explicitSenderDomain && !extractedDomains.includes(explicitSenderDomain)) {
    extractedDomains.unshift(explicitSenderDomain);
  }
  const fromDomains = extractFromDomains(text);
  const senderDomain = (auth && auth.fromDomain)
    ? auth.fromDomain.toLowerCase().trim().replace(/^www\./, "")
    : (explicitSenderDomain || fromDomains[0] || (extractedDomains.length ? extractedDomains[0] : ""));

  if (explicitSenderDomain) {
    for (const brand of MATCHABLE_BRANDS) {
      const officialDomains = OFFICIAL_BRAND_DOMAINS[brand] || [`${brand}.com`];
      const isOfficial = officialDomains.some(official => explicitSenderDomain === official || explicitSenderDomain.endsWith(`.${official}`));
      if (isOfficial && !isFreeMailDomain(explicitSenderDomain)) {
        isBrandSender = true;
        break;
      }
    }
  }

  // 0. Cryptographic / Header Authentication Evaluation
  let isAuthDisqualified = false;
  let isAuthAligned = true;
  if (auth && typeof auth === "object") {
    const authResult = evaluateAuthentication(auth, senderDomain);
    if (authResult.flags.length > 0) {
      flags.push(...authResult.flags);
      rawScore += authResult.score;
    }
    isAuthDisqualified = authResult.isAuthDisqualified;

    const fromDom = (auth.fromDomain || senderDomain || "").toLowerCase().trim().replace(/^www\./, "");
    if (auth.signedBy) {
      const sBy = auth.signedBy.toLowerCase().trim().replace(/^www\./, "");
      isAuthAligned = (sBy === fromDom || sBy.endsWith("." + fromDom)) && !isAuthDisqualified;
    } else {
      isAuthAligned = !isAuthDisqualified && !isProtectedBrandDomain(fromDom);
    }
  }

  // 1. Homoglyph, Typosquat & Subdomain Brand-Stuffing Checks
  for (const rawDomain of extractedDomains) {
    const parts = rawDomain.split(".");
    if (parts.length < 2) continue;

    // A domain we know belongs to a real company is never a spoof, however
    // close it sits to a brand name (shopify.com vs spotify.com).
    if (LEGITIMATE_DOMAINS.has(rawDomain)) {
      isBrandSender = true;
      continue;
    }

    // Officially some brand's own domain: never a typosquat of a different one.
    // Free webmail is excluded - gmail.com belongs to Google, but a message
    // sent from a personal mailbox is not an official Google message.
    if (ALL_OFFICIAL_DOMAINS.has(rawDomain) && !isFreeMailDomain(rawDomain)) {
      isBrandSender = true;
      continue;
    }

    const sld = parts[parts.length - 2];
    const fullHost = parts.slice(0, parts.length - 1).join(".");
    const normalizedSld = normalizeForBrandCheck(sld);
    const normalizedFullHost = normalizeForBrandCheck(fullHost);
    // Second reading of the same domain, with `1` standing for "l".
    const normalizedAltSld = normalizeAltForBrandCheck(sld);

    for (const brand of MATCHABLE_BRANDS) {
      const isShortCarrier = SHORT_CARRIER_BRANDS.has(brand);
      const officialDomains = OFFICIAL_BRAND_DOMAINS[brand] || [`${brand}.com`];
      const isOfficial = officialDomains.some(official => rawDomain === official || rawDomain.endsWith(`.${official}`));

      if (isOfficial) {
        // A free mailbox is never an official sender, even when the domain
        // genuinely belongs to the brand (gmail.com is Google's, but a message
        // sent from a personal Gmail is not a message from Google).
        if (!isFreeMailDomain(rawDomain)) isBrandSender = true;
        continue;
      }

      // Check A: Character substitution (Homoglyph, e.g. m1crosoft -> microsoft,
      // paypa1 -> paypal). Either reading of the digit may resolve the brand.
      const hasHomoglyphSubstitution = !isShortCarrier &&
        (normalizedSld.includes(brand) || normalizedAltSld.includes(brand)) && !sld.includes(brand);

      // Check B: Subdomain or hyphen brand-stuffing (e.g. microsoft-support.com, login-microsoft.com)
      const hasBrandStuffing = !isOfficial && (
        isShortCarrier
          ? new RegExp(`(^|[-.])${brand}([-.]|$)`, "i").test(fullHost)
          : (normalizedFullHost.includes(brand) || sld.includes(brand))
      );

      // Check C: Levenshtein distance check (e.g. microsft, micosoft, appple)
      // The length must also be within +/-2, otherwise unrelated short domains
      // can sit an edit or two away from a brand by coincidence.
      const distance = isShortCarrier ? 99 : Math.min(
        levenshteinDistance(normalizedSld, brand),
        levenshteinDistance(normalizedAltSld, brand)
      );
      const lengthDelta = Math.abs(sld.length - brand.length);
      const isCloseTypo = !isShortCarrier && distance > 0 && distance <= 2 && lengthDelta <= 2 && sld.length >= MIN_BRAND_LEN;

      if (hasHomoglyphSubstitution) {
        flags.push({
          span: rawDomain,
          reason: `Homoglyph/Typosquat domain: '${rawDomain}' uses character substitution to impersonate brand '${brand.toUpperCase()}'`,
          type: "rule"
        });
        rawScore += 65;
      } else if (hasBrandStuffing) {
        flags.push({
          span: rawDomain,
          reason: `Brand impersonation/stuffing: '${rawDomain}' uses brand name '${brand.toUpperCase()}' without official ownership`,
          type: "rule"
        });
        rawScore += 60;
      } else if (isCloseTypo) {
        flags.push({
          span: rawDomain,
          reason: `Typosquatting domain: '${rawDomain}' is suspiciously close to brand '${brand.toUpperCase()}'`,
          type: "rule"
        });
        rawScore += 55;
      }
    }
  }

  const isLegitimateOfficialSender = isBrandSender && isAuthAligned && !isAuthDisqualified;

  // 2. Urgency and Credential Patterns
  let hasUrgency = false;
  let hasCredentialRequest = false;

  for (const pattern of URGENCY_PATTERNS) {
    const match = text.match(pattern.regex);
    if (match) {
      flags.push({ span: match[0], reason: pattern.reason, type: "rule" });
      rawScore += 25;
      hasUrgency = true;
    }
  }

  for (const pattern of CREDENTIAL_PATTERNS) {
    const match = text.match(pattern.regex);
    if (match) {
      flags.push({ span: match[0], reason: pattern.reason, type: "rule" });
      rawScore += 30;
      hasCredentialRequest = true;
    }
  }

  // 2b. Social-engineering families (advance-fee, refund bait, delivery fee,
  // fake subscription, fake 2FA, investment, health, ID harvest, cold-contact).
  //
  // Each family is capped at one contribution no matter how many of its
  // patterns match. A single advance-fee email usually trips four or five of
  // them ("lucky winner", a million-dollar figure, Western Union, an
  // activation fee); without the cap one message would score like four
  // separate scams.
  const firedFamilies = new Set();
  for (const family of SOCIAL_ENGINEERING_FAMILIES) {
    if (firedFamilies.has(family.name)) continue;
    let hits = 0;
    for (const pattern of family.patterns) {
      const match = text.match(pattern.regex);
      if (!match) continue;
      firedFamilies.add(family.name);
      flags.push({ span: match[0], reason: pattern.reason, type: "rule" });
      rawScore += family.points;
      hits++;
      // A second corroborating pattern from the same family is real additional
      // evidence, but it is worth less than the first: an advance-fee email
      // matches many of its own patterns, and counting them all would let one
      // family outvote a genuine cross-family combination. Half value, and
      // never more than two contributions per family.
      //
      // Families can opt out. personal_data does, because its patterns are
      // interchangeable spellings of a single request - a legitimate HR form
      // asking for "Your Full Names:", "Your Country:" and "Cell/Telephone
      // Number:" trips three of them and is not three times more suspicious.
      if (hits >= 2 || family.corroboration === false) break;
      rawScore += Math.round(family.points * 0.5);
    }
  }

  const hasMoneyBait = firedFamilies.has("advance_fee") ||
    firedFamilies.has("refund_bait") || firedFamilies.has("investment") ||
    firedFamilies.has("delivery_fee");
  const hasActionRequest = firedFamilies.has("personal_data") ||
    firedFamilies.has("contact_stranger") || firedFamilies.has("fake_security") ||
    firedFamilies.has("fake_subscription");

  // 2b-1. Reply-To points somewhere other than the sending domain.
  //
  // A From: that looks institutional while Reply-To: is a free webmail or
  // lookalike host is a deliberate attempt to defeat reply-path filtering on
  // the receiving organisation. This fires independently of any brand list, so
  // it works for institutions the engine has never heard of.
  const replyToDomains = extractReplyToDomains(text);
  const replyToRedirect = replyToDomains.find(
    (rt) => !fromDomains.some((fd) => rt === fd || rt.endsWith("." + fd) || fd.endsWith("." + rt))
  );
  if (replyToRedirect) {
    flags.push({
      span: replyToRedirect,
      reason:
        "Reply-To redirect: replies are routed to " + replyToRedirect +
        (fromDomains.length ? " instead of the sending domain " + fromDomains.join(", ") : ""),
      type: "rule"
    });
    rawScore += 25;
  }

  // 2b-2. Mixed-script homoglyphs inside otherwise-Latin words.
  const mixedScript = findMixedScriptTokens(text);
  if (mixedScript.length > 0) {
    flags.push({
      span: mixedScript[0].token,
      reason:
        "Mixed-script homoglyph: '" + mixedScript[0].token +
        "' contains non-Latin characters (U+" +
        mixedScript[0].nonLatin.map((c) => c.charCodeAt(0).toString(16).toUpperCase().padStart(4, "0")).join(" U+") +
        "), which is invisible to the reader and used to spoof a brand",
      type: "rule"
    });
    rawScore += 30;
  }

  // 2b-3. Sender on free / anonymous hosting.
  //
  // Checked against the From: domain, not only links in the body: a lookalike
  // bank notice is routinely sent straight from Firebase Hosting with no link
  // in the body at all, so the existing body-only rule never sees it.
  const abusedHostSender = fromDomains.find((d) => ABUSED_HOSTING_RE.test(d));
  if (abusedHostSender) {
    flags.push({
      span: abusedHostSender,
      reason: "Sender domain is free anonymous hosting, commonly used to serve brand lookalikes",
      type: "rule"
    });
    rawScore += 20;
  }

  // 2b-4. A large monetary amount with a currency code or symbol.
  if (LARGE_AMOUNT_RE.test(text) && !firedFamilies.has("advance_fee")) {
    const amt = text.match(LARGE_AMOUNT_RE);
    flags.push({
      span: amt[0].trim(),
      reason: "Large monetary amount quoted unsolicited",
      type: "rule"
    });
    rawScore += 15;
  }

  // 2c. Display-name brand impersonation.
  //
  // The checks above only ever look at the sending domain, so a message
  // claiming to be "MetaMask" from an anonymous *.firebaseapp.com host looks
  // like ordinary mail to them. The display name is where attackers are
  // careless, and a mismatch against a known brand is very high precision.
  const displayNames = extractSenderDisplayNames(text);
  if (explicitSenderName && !displayNames.includes(explicitSenderName)) {
    displayNames.unshift(explicitSenderName);
  }
  const senderDomainsForDisplay = extractSenderDomains(text);
  if (explicitSenderDomain && !senderDomainsForDisplay.includes(explicitSenderDomain)) {
    senderDomainsForDisplay.unshift(explicitSenderDomain);
  }
  const claimedBrands = [];
  for (const name of displayNames) {
    const normalizedName = normalizeForBrandCheck(name).replace(/\s+/g, "");
    const altName = normalizeAltForBrandCheck(name).replace(/\s+/g, "");
    for (const brand of MATCHABLE_BRANDS) {
      const isShortCarrier = SHORT_CARRIER_BRANDS.has(brand);
      if (brand.length < 5 && !isShortCarrier) continue;
      let hit = false;
      if (isShortCarrier) {
        hit = new RegExp(`\\b${brand}\\b`, "i").test(name);
      } else {
        hit = normalizedName.includes(brand) || altName.includes(brand) ||
          name.toLowerCase().replace(/\s+/g, "").includes(brand);
      }
      if (!hit) continue;
      // An official brand domain is allowed to use its own name. The
      // `${brand}.com` fallback matters: without it, every brand missing an
      // entry in OFFICIAL_BRAND_DOMAINS (coinbase, dropbox, binance, ...) was
      // treated as impersonating itself, which flagged their own legitimate
      // mail.
      const official = OFFICIAL_BRAND_DOMAINS[brand] || [`${brand}.com`];
      // Free webmail never counts as official: "MetaMask" from a personal
      // Gmail address is impersonation, not a message from MetaMask.
      const senderIsOfficial = senderDomainsForDisplay.some(
        (d) => !isFreeMailDomain(d) && official.some((o) => d === o || d.endsWith("." + o))
      );
      if (!senderIsOfficial) claimedBrands.push({ name, brand, senderDomains: senderDomainsForDisplay });
      break;
    }
  }
  if (claimedBrands.length > 0) {
    for (const claim of claimedBrands) {
      flags.push({
        span: claim.name,
        reason:
          "Brand impersonation: sender is displayed as '" + claim.name +
          "' but the message does not come from an official " +
          claim.brand.toUpperCase() + " domain" +
          (claim.senderDomains.length ? " (actual: " + claim.senderDomains.join(", ") + ")" : ""),
        type: "rule"
      });
      rawScore += 55;
    }
  }

  // 3d. Money-bait + action-request COMBO.
  //
  // This is the single most important new rule. Neither half is conclusive on
  // its own: plenty of legitimate mail mentions a refund or a renewal, and
  // plenty of legitimate mail asks you to contact support. Together they
  // describe the advance-fee shape almost exactly - an unexpected financial
  // claim that can only be released by sending data, money, or a reply to a
  // third party.
  if (hasMoneyBait && hasActionRequest && !isLegitimateOfficialSender) {
    flags.push({
      span: "Money bait + unsolicited action request",
      reason:
        "High-risk combination: an unexpected financial claim is paired with a " +
        "request for personal data, payment, or an off-channel reply",
      type: "rule"
    });
    rawScore += 45;
  }

  // 3e. Advance-fee shape: money promised, but a fee is required up front.
  if (firedFamilies.has("advance_fee") && /activat\w*\s+fee|to\s+(start|proceed|receive)[^.]{0,40}(pay|send|fee)|pay\s+them?\s+the|small\s+(fee|charge)/i.test(text) && !isLegitimateOfficialSender) {
    flags.push({
      span: "Advance-fee pretext",
      reason:
        "Advance-fee fraud signature: a large sum is promised, but a fee must " +
        "be paid before it is released",
      type: "rule"
    });
    rawScore += 40;
  }

  // 2d. Brand claimed in a signature footer, but the sender domain is not
  // official for that brand.
  //
  // "© 2025 PayPal, LLC" in the body of a message sent from an unrelated
  // throwaway domain is a stronger impersonation tell than anything the domain
  // checks can see, because those checks only ever read the domain.
  const hasSignatureFooter = SIGNATURE_FOOTER_PATTERNS.some((re) => re.test(text));
  if (hasSignatureFooter && !isLegitimateOfficialSender) {
    const bodyBrands = MATCHABLE_BRANDS.filter((brand) => {
      const isShortCarrier = SHORT_CARRIER_BRANDS.has(brand);
      if (brand.length < 4 && !isShortCarrier) return false;
      const official = OFFICIAL_BRAND_DOMAINS[brand] || [`${brand}.com`];
      const senderIsOfficial = senderDomainsForDisplay.some(
        (d) => !isFreeMailDomain(d) && official.some((o) => d === o || d.endsWith("." + o))
      );
      if (senderIsOfficial) return false;
      return new RegExp(
        "(?:©|\\(c\\)|copyright)\\s*(?:\\d{4})?\\s*(?:by\\s+)?(?:[\\w.,]+\\s+){0,3}\\b" + brand + "\\b|\\b" + brand + "\\b\\s*(?:[\\w.,]+\\s+){0,3}(?:LLC|Inc|Ltd|B\\.?\\s*V\\.?|GmbH|Pte|Corporation)",
        "i"
      ).test(text);
    });
    for (const brand of bodyBrands) {
      const display = new RegExp("(" + brand + "[\\w. ]{0,28})", "i").exec(text);
      flags.push({
        span: display ? display[1].trim() : brand,
        reason:
          "Signature claims " + brand.toUpperCase() +
          " but the message is not sent from an official " + brand + " domain" +
          (senderDomainsForDisplay.length ? " (actual sender: " + senderDomainsForDisplay.join(", ") + ")" : ""),
        type: "rule"
      });
      rawScore += 45;
      break;
    }
  }

  // 3d-1. Advance-fee claim that also quotes a concrete large sum.
  //
  // Neither half is decisive alone: a newsletter can mention a lottery win, and
  // an invoice quotes a six-figure total every day. Together they describe the
  // advance-fee shape - an unsolicited payout claim with a specific amount,
  // delivered to someone who never asked for it.
  if (firedFamilies.has("advance_fee") && SIX_FIGURE_AMOUNT_RE.test(text) && !isLegitimateOfficialSender) {
    flags.push({
      span: "Unsolicited payout claim with a specific large amount",
      reason:
        "High-risk combination: an unsolicited prize, grant or compensation " +
        "claim quotes a specific six-figure or larger sum",
      type: "rule"
    });
    rawScore += 25;
  }

  // 3. Urgency + Credential harvesting COMBO Boost
  if (hasUrgency && hasCredentialRequest && !isLegitimateOfficialSender) {
    flags.push({
      span: "Urgency + Credential Harvesting Combo",
      reason: "High-risk combination: Urgency pressure combined with credential login request",
      type: "rule"
    });
    rawScore += 45;
  }

  // 3b. URL shortener + pressure COMBO (smishing / delivery-fraud signature)
  let hasShortener = false;
  for (const pattern of SUSPICIOUS_DOMAINS) {
    const match = text.match(pattern.regex);
    if (match) {
      flags.push({ span: match[0], reason: pattern.reason, type: "rule" });
      rawScore += 35;
      if (pattern.reason.indexOf("shortener") !== -1) hasShortener = true;
    }
  }

  if (hasShortener && (hasUrgency || hasCredentialRequest) && !isLegitimateOfficialSender) {
    flags.push({
      span: "Concealed link + pressure",
      reason:
        "High-risk combination: a shortened link hides the true destination while the message applies time pressure",
      type: "rule"
    });
    rawScore += 30;
  }

  // 3c. Sender / link domain mismatch (spec Part 1.3)
  // Only evaluated for senders that are NOT an official brand domain, so that
  // legitimate cross-domain mail (GitHub -> Vercel) is never penalised.
  const senderDomains = extractSenderDomains(text);
  if (explicitSenderDomain && !senderDomains.includes(explicitSenderDomain)) {
    senderDomains.unshift(explicitSenderDomain);
  }
  const linkDomains = extractLinkDomains(text);
  if (!isLegitimateOfficialSender && senderDomains.length && linkDomains.length) {
    for (const sender of senderDomains) {
      const senderReg = registeredDomain(sender);
      const offDomainLinks = linkDomains.filter((link) => {
        const linkReg = registeredDomain(link);
        return linkReg !== senderReg && linkReg !== sender && senderReg !== linkReg;
      });
      if (offDomainLinks.length) {
        flags.push({
          span: sender,
          reason:
            "Sender/link mismatch: message is sent from '" + sender +
            "' but links point to " + offDomainLinks.slice(0, 3).join(", "),
          type: "rule"
        });
        rawScore += 30;
        break;
      }
    }
  }

  // 4. Promotional Clutter Check
  //
  // Demotion to "bulk marketing" is only defensible when the message carries
  // NO threat evidence at all. The guard used to be `rawScore < 40`, which is a
  // score threshold standing in for a semantic question, and it silently
  // demoted a real scam: SCAM-017 (a quack back-pain device advertorial making
  // unverifiable therapeutic claims) tripped two generic marketing patterns -
  // "Unsubscribe" and "60% discount" - while matching no health-claim pattern,
  // so it was reported as marketing rather than as a threat. The corpus suite
  // never caught it, because promo scores are floored at 45 and the old
  // "score >= 35 means detected" metric read that floor as a detection.
  //
  // The floor stays: a genuine cold blast must still be visibly separated from
  // a clean message, and the verdict ladder gives promo_clutter its own
  // "unsubscribe this" action.
  let promoCount = 0;
  let hasHighIntentPromo = false;
  for (const pattern of PROMOTIONAL_CLUTTER_PATTERNS) {
    const match = text.match(pattern.regex);
    if (match) {
      flags.push({ span: match[0], reason: pattern.reason, type: "promo" });
      promoCount++;
      if (pattern.highIntent) hasHighIntentPromo = true;
    }
  }

  // Check transactional safeguard
  const hasTransactionalSafeguard = TRANSACTIONAL_SAFEGUARD_PATTERNS.some((p) => p.regex.test(text));

  // Any non-promotional flag means the message is doing something other than
  // selling, and a phishing lure must never be relabelled as marketing. This
  // is checked on flags rather than on the running score so that a scam which
  // trips only high-value signals (brand impersonation, a homoglyph, a
  // Reply-To redirect) cannot be bought back under the promo floor.
  const hasThreatEvidence = flags.some((f) => f.type !== "promo" && f.type !== "quarantine");
  if ((hasHighIntentPromo || promoCount >= 2) && !hasThreatEvidence && !hasTransactionalSafeguard) {
    isPromoClutter = true;
    rawScore = Math.max(45, Math.min(58, 45 + promoCount * 4));
  } else if (hasTransactionalSafeguard && !hasThreatEvidence && !hasHighIntentPromo) {
    rawScore = Math.min(12, rawScore);
  }

  // Mailbox-provider quarantine notice. This runs BEFORE the official-domain
  // cap below, because that cap clamps any brand-domain mail to 25 and would
  // otherwise erase the one signal that matters here: Gmail has already
  // quarantined this message and told the user why.
  let isQuarantined = false;
  let quarantineEscalated = false;
  for (const pattern of QUARANTINE_NOTICE_PATTERNS) {
    const match = text.match(pattern.regex);
    if (!match) continue;
    flags.push({ span: match[0], reason: pattern.reason, type: "quarantine" });
    isQuarantined = true;
    if (pattern.escalate) quarantineEscalated = true;
  }

  // A blocked sender is a user preference, not proof of a threat, so this floors
  // the score into the unwanted-marketing band instead of forcing high_risk. It
  // still has to clear "safe", because reporting a message the user's own
  // mailbox quarantined as "consistent with legitimate mail" is the exact
  // contradiction this fixes.
  if (isQuarantined) {
    rawScore = Math.max(rawScore, 45);
    if (quarantineEscalated) rawScore = Math.max(rawScore, 70);
  }

  // 5. Official Domain Exemption: If official sender domain with no typosquats, cap false positives
  //
  // The quarantine floor is deliberately excluded from this cap. An official
  // brand domain being legitimate says nothing about whether THIS message was
  // filtered, and letting the cap win is what produced "SAFE / 16" beside a red
  // RISK 78 badge for the same message.
  if (isLegitimateOfficialSender && !hasCredentialRequest && !isQuarantined) {
    rawScore = Math.min(25, rawScore);
  }

  const authStatus = isAuthDisqualified
    ? "spoof"
    : (auth && auth.signedBy && isAuthAligned ? "verified" : "unverified");

  const finalRuleScore = Math.min(100, rawScore);
  return {
    ruleScore: finalRuleScore,
    flags,
    isPromoClutter,
    isQuarantined,
    isAuthDisqualified,
    authSummary: {
      status: authStatus,
      fromDomain: (auth && auth.fromDomain) || senderDomain || null,
      signedBy: (auth && auth.signedBy) || null,
      mailedBy: (auth && auth.mailedBy) || null
    }
  };
}

module.exports = {
  evaluateRules,
  evaluateAuthentication,
  isProtectedBrandDomain,
  normalizeForBrandCheck,
  normalizeAltForBrandCheck,
  levenshteinDistance,
  extractSenderDomains,
  extractFromDomains,
  extractReplyToDomains,
  findMixedScriptTokens,
  isFreeMailDomain,

  /**
   * Machine-readable description of the detection model.
   *
   * Exported so tooling can enumerate what the engine actually looks for
   * instead of scraping the source or re-deriving it from prose. Anything
   * added to the rule tables above should be reflected here; the taxonomy is
   * derived from the same constants the engine runs on, so it cannot drift.
   */
  TAXONOMY: {
    version: 2,
    brands: MATCHABLE_BRANDS,
    officialBrandDomains: OFFICIAL_BRAND_DOMAINS,
    legitimateDomains: Array.from(LEGITIMATE_DOMAINS),
    freeMailDomains: Array.from(FREE_MAIL_DOMAINS),
    socialEngineeringFamilies: SOCIAL_ENGINEERING_FAMILIES.map((f) => ({
      name: f.name,
      points: f.points,
      corroboration: f.corroboration !== false,
      patternCount: f.patterns.length,
      patterns: f.patterns.map((p) => p.reason),
    })),
    structuralSignals: require("../laya/client").STRUCTURAL_SIGNALS.map((s) => ({
      name: s.name,
      weight: s.weight,
    })),
    patternTables: {
      urgency: URGENCY_PATTERNS.length,
      credential: CREDENTIAL_PATTERNS.length,
      promotionalClutter: PROMOTIONAL_CLUTTER_PATTERNS.length,
      transactionalSafeguards: TRANSACTIONAL_SAFEGUARD_PATTERNS.length,
      suspiciousDomains: SUSPICIOUS_DOMAINS.length,
      advanceFee: ADVANCE_FEE_PATTERNS.length,
      refundBait: REFUND_BAIT_PATTERNS.length,
      deliveryFee: DELIVERY_FEE_PATTERNS.length,
      fakeSubscription: FAKE_SUBSCRIPTION_PATTERNS.length,
      fakeSecurity: FAKE_SECURITY_PATTERNS.length,
      investment: INVESTMENT_PATTERNS.length,
      healthClaim: HEALTH_CLAIM_PATTERNS.length,
      personalData: PERSONAL_DATA_PATTERNS.length,
      contactStranger: CONTACT_STRANGER_PATTERNS.length,
      inheritance: INHERITANCE_PATTERNS.length,
    },
    scoring: {
      minBrandLength: MIN_BRAND_LEN,
      levenshteinMaxDistance: 2,
      levenshteinMaxLengthDelta: 2,
      confidenceFloor: 0.02,
      confidenceCeiling: 0.99,
    },
  },
};
