/**
 * Ratio'd API Route: POST /analyze
 * Exact Part A.5 API Contract: Accepts { text, channel }
 */
const { evaluateRules } = require("../rules/engine");
const { evaluateLayaModel } = require("../laya/client");
const { generateExplanation } = require("../llm/explain");
const { combineScore } = require("../combine/score");
const { logPrivacyTelemetry } = require("../privacy/log");

function computePrivacyStatsFromText(text) {
  const phonesMatch = text.match(/\[PHONE_REDACTED\]|(\+?\d{1,3}[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}/g);
  const emailsMatch = text.match(/\[EMAIL_REDACTED\]|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g);
  const otpMatch = text.match(/\[OTP_REDACTED\]|\b(OTP|code|passcode|PIN)\b(?:\s+(?:is|was|:|-))?\s*:?\s*(\d{4,8})\b/gi);

  return {
    phones_masked: phonesMatch ? phonesMatch.length : 0,
    emails_masked: emailsMatch ? emailsMatch.length : 0,
    otp_masked: otpMatch ? otpMatch.length : 0
  };
}

async function handleAnalyze(reqBody) {
  const startedAt = Date.now();
  const { text, channel = "email", auth: rawAuth, senderAddress, senderName } = reqBody;

  if (!text || typeof text !== "string") {
    throw new Error("Missing or invalid 'text' field in request body.");
  }

  const validChannel = (channel === "sms" || channel === "email") ? channel : "email";

  const cleanSenderAddress = (typeof senderAddress === "string") ? senderAddress.trim() : "";
  const cleanSenderName = (typeof senderName === "string") ? senderName.trim() : "";
  const senderInfo = (cleanSenderAddress || cleanSenderName)
    ? { senderAddress: cleanSenderAddress, senderName: cleanSenderName }
    : null;

  // Sanitize authentication payload if present
  let auth = null;
  if (rawAuth && typeof rawAuth === "object") {
    const sanitizeStr = (s) => {
      if (!s || typeof s !== "string") return null;
      const clean = s.toLowerCase().trim().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
      return clean.length > 0 ? clean : null;
    };
    const fromDomain = sanitizeStr(rawAuth.fromDomain);
    const mailedBy = sanitizeStr(rawAuth.mailedBy);
    const signedBy = sanitizeStr(rawAuth.signedBy);
    const dmarc = sanitizeStr(rawAuth.dmarc);
    const spf = sanitizeStr(rawAuth.spf);
    const dkim = sanitizeStr(rawAuth.dkim);

    if (fromDomain || mailedBy || signedBy || dmarc || spf || dkim) {
      auth = { fromDomain, mailedBy, signedBy, dmarc, spf, dkim };
    }
  }

  // 1. Compute privacy redaction counts on backend from incoming client-redacted telemetry
  const privacyStats = computePrivacyStatsFromText(text);

  // 2. Evaluate Rule Engine
  const { ruleScore, flags, isPromoClutter, isAuthDisqualified, authSummary } = evaluateRules(text, validChannel, auth, senderInfo);

  // 3. Evaluate Laya Model (Stating transparently whether heuristic fallback or container)
  const layaResult = await evaluateLayaModel(text, flags);

  // 4. Combine Scores & Build Next Steps
  // isPromoClutter is forwarded deliberately: the engine already decided
  // promo-clutter using a 2+ signal threshold and a low-score cap. Recomputing
  // it here from "any promo flag" labelled ordinary newsletters as clutter.
  const { score, verdict, next_steps } = combineScore(ruleScore, layaResult, validChannel, flags, isPromoClutter, isAuthDisqualified);

  // 5. Generate Grounded Explanation.
  // Deterministic by default; uses the LLM prompt only when a key is configured,
  // and the returned source is reported verbatim so nothing is ever implied.
  const { explanation, source: explainSource, model: explainModel } =
    await generateExplanation(verdict, flags, validChannel, text);

  // 6. Log Privacy Telemetry (Zero raw text persistence)
  logPrivacyTelemetry(validChannel, privacyStats);

  // 7. Return Exact Contract (Part A.5) + transparent engine metadata.
  // The engine block reports what ACTUALLY ran — including the explicit
  // `laya_stub_heuristic` label, so no model score is ever implied to be real.
  return {
    score,
    verdict,
    flags,
    explanation,
    next_steps,
    privacy: privacyStats,
    auth: authSummary || null,
    engine: {
      rules: "deterministic-homoglyph-levenshtein",
      rule_flags: flags.length,
      auth_status: authSummary ? authSummary.status : "unverified",
      model_source: layaResult.source,
      model_label: layaResult.label,
      model_probability: layaResult.probability,
      model_signals: layaResult.signals || [],
      model_note: layaResult.note,
      explain: "grounded-in-flags",
      explain_source: explainSource,
      explain_model: explainModel,
      latency_ms: Date.now() - startedAt
    }
  };
}

module.exports = { handleAnalyze };
