/**
 * Ratio'd Gmail Content Script (Matches Part A.5 Contract)
 */

function redactPiiLocally(text) {
  if (!text) return "";

  // Phone regex
  const phoneRegex = /(\+?\d{1,3}[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}/g;
  let redacted = text.replace(phoneRegex, "[PHONE_REDACTED]");

  // Email regex
  const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  redacted = redacted.replace(emailRegex, "[EMAIL_REDACTED]");

  // OTP regex
  const otpRegex = /\b(OTP|code|passcode|PIN)?\s?:?\s?(\d{4,8})\b/gi;
  redacted = redacted.replace(otpRegex, (match, prefix, digits) => {
    return (prefix ? prefix + " " : "") + "[OTP_REDACTED]";
  });

  return redacted;
}

let lastAnalyzedMessageId = null;

function scanAndAnalyzeGmail() {
  const emailBodyElem = document.querySelector(".a3s.aiL, .a3s, [role='main'] .h7");
  if (!emailBodyElem) return;

  const messageText = emailBodyElem.innerText || "";
  if (messageText.length < 10) return;

  const currentMessageHash = messageText.substring(0, 100) + messageText.length;
  if (lastAnalyzedMessageId === currentMessageHash) return;

  lastAnalyzedMessageId = currentMessageHash;

  console.log("[RATIO'D EXTENSION] Open Gmail email detected. Redacting PII locally...");

  // 1. Client-Side Local PII Redaction
  const redactedText = redactPiiLocally(messageText);

  // 2. Request Analysis from Backend Service (Part A.5: { text, channel })
  fetch("http://127.0.0.1:3000/analyze", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      text: redactedText,
      channel: "email"
    })
  })
    .then(res => res.json())
    .then(data => {
      console.log("[RATIO'D EXTENSION] Analysis verdict received:", data);
      if (window.injectRatiodBanner) {
        window.injectRatiodBanner(emailBodyElem.parentElement || emailBodyElem, data);
      }
    })
    .catch(err => {
      console.warn("[RATIO'D EXTENSION] Backend unavailable, running local fallback engine...");
      const phonesMatch = redactedText.match(/\[PHONE_REDACTED\]/g);
      const emailsMatch = redactedText.match(/\[EMAIL_REDACTED\]/g);

      const fallbackData = {
        score: redactedText.includes("urgent") ? 75 : 15,
        verdict: redactedText.includes("urgent") ? "high_risk" : "safe",
        flags: [{ span: "urgent", reason: "Potential urgency pattern", type: "rule" }],
        explanation: "Analysis performed via client-side fallback engine.",
        next_steps: ["Do not click unverified links.", "Verify sender identity."],
        privacy: {
          phones_masked: phonesMatch ? phonesMatch.length : 0,
          emails_masked: emailsMatch ? emailsMatch.length : 0,
          otp_masked: 0
        }
      };
      if (window.injectRatiodBanner) {
        window.injectRatiodBanner(emailBodyElem.parentElement || emailBodyElem, fallbackData);
      }
    });
}

const observer = new MutationObserver(() => {
  scanAndAnalyzeGmail();
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

setTimeout(scanAndAnalyzeGmail, 2000);
