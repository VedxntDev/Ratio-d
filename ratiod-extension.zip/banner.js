/**
 * Ratio'd Shadow DOM Banner Injector for Gmail
 * Ensures complete CSS isolation from Gmail's page styles.
 */

function injectRatiodBanner(targetElement, data) {
  if (!targetElement) return;

  // Remove existing banner if present
  const existingHost = document.getElementById("ratiod-banner-host");
  if (existingHost) {
    existingHost.remove();
  }

  // Create Shadow Host
  const host = document.createElement("div");
  host.id = "ratiod-banner-host";
  const shadowRoot = host.attachShadow({ mode: "open" });

  // Load isolated stylesheet
  const linkElem = document.createElement("link");
  linkElem.setAttribute("rel", "stylesheet");
  linkElem.setAttribute("href", chrome.runtime.getURL("banner.css"));
  shadowRoot.appendChild(linkElem);

  // Build markup
  const container = document.createElement("div");
  container.className = "ratiod-container";

  const verdict = data.verdict || "safe";
  const score = data.score !== undefined ? data.score : 0;
  const flags = data.flags || [];
  const explanation = data.explanation || "No threat signals detected.";
  const nextSteps = data.next_steps || [];
  const privacy = data.privacy || { phones_masked: 0, emails_masked: 0, otp_masked: 0 };

  const totalMasked = (privacy.phones_masked || 0) + (privacy.emails_masked || 0) + (privacy.otp_masked || 0);

  container.innerHTML = `
    <div class="ratiod-header">
      <div class="ratiod-badge-group">
        <span class="ratiod-tag tag-${verdict}">[ RATIO'D · ${verdict.toUpperCase()} ]</span>
        <span class="ratiod-score">RISK SCORE: ${score}/100</span>
      </div>
      <div style="font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 700;">
        [ PRIVACY · ${totalMasked} REDACTED · AIR-GAPPED ]
      </div>
    </div>

    <div class="ratiod-body">
      <div class="ratiod-explanation">${explanation}</div>
      <div class="ratiod-actions">
        <button class="ratiod-btn ratiod-btn-primary" id="toggle-drawer">[ SEE FULL THREAT DETAILS ]</button>
        <button class="ratiod-btn" id="toggle-checklist">[ RECOVERY CHECKLIST ]</button>
      </div>

      <div class="ratiod-drawer" id="analysis-drawer">
        <div class="drawer-section-title">[ DETECTED THREAT SPANS ]</div>
        ${flags.length > 0 ? flags.map(f => `
          <div class="flag-item">
            <span class="flag-span">${f.span}</span> — ${f.reason}
          </div>
        `).join('') : '<div class="flag-item">No explicit rule flags triggered.</div>'}

        <div class="drawer-section-title" style="margin-top: 12px;">[ RECOMMENDED ACTION CHECKLIST ]</div>
        <ul class="checklist-list">
          ${nextSteps.map(step => `<li><strong>•</strong> ${step}</li>`).join('')}
        </ul>

        <div class="privacy-footnote">
          ✓ Real-time PII redaction active: ${privacy.phones_masked || 0} phone(s), ${privacy.emails_masked || 0} email(s) masked before analysis. Zero message text stored.
        </div>
      </div>
    </div>
  `;

  shadowRoot.appendChild(container);
  targetElement.prepend(host);

  // Wire event handlers inside Shadow DOM
  const toggleBtn = shadowRoot.getElementById("toggle-drawer");
  const checklistBtn = shadowRoot.getElementById("toggle-checklist");
  const drawer = shadowRoot.getElementById("analysis-drawer");

  if (toggleBtn && drawer) {
    toggleBtn.addEventListener("click", () => {
      drawer.classList.toggle("open");
    });
  }

  if (checklistBtn && drawer) {
    checklistBtn.addEventListener("click", () => {
      drawer.classList.add("open");
      drawer.scrollIntoView({ behavior: "smooth" });
    });
  }
}

window.injectRatiodBanner = injectRatiodBanner;
